<?php
include 'db.php';

if (!isset($_GET['id'])) {
    die("ID manquant !");
}

$id = intval($_GET['id']);

// Récupérer les infos du fichier
$stmt = $conn->prepare("SELECT * FROM fichiers WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$file = $result->fetch_assoc();

if (!$file) {
    die("Fichier introuvable !");
}

// Traitement de la mise à jour
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nouveau_nom = $_POST['nom_fichier'];
    $nouvelle_categorie = $_POST['categorie'];

    $stmt = $conn->prepare("UPDATE fichiers SET nom_fichier = ?, categorie = ? WHERE id = ?");
    $stmt->bind_param("ssi", $nouveau_nom, $nouvelle_categorie, $id);
    $stmt->execute();

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier le PDF</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>✏ Modifier le fichier PDF</h2>

    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Nom du fichier</label>
            <input type="text" name="nom_fichier" class="form-control" value="<?= htmlspecialchars($file['nom_fichier']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Catégorie</label>
            <input type="text" name="categorie" class="form-control" value="<?= htmlspecialchars($file['categorie']) ?>" required>
        </div>
        <button type="submit" class="btn btn-success">✅ Enregistrer</button>
        <a href="admin.php" class="btn btn-secondary">❌ Annuler</a>
    </form>
</div>

</body>
</html>
