<?php
include 'db.php';

// Récupération des fichiers depuis la base de données
$sql = "SELECT * FROM fichiers ORDER BY date_upload DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque de PDFs</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">
    <h2 class="my-4 text-center">📚 BIBLIOTHEQUE AEMCI-UFHB</h2>

    <!-- Formulaire d'upload -->
   

    <!-- Recherche -->
    <input type="text" id="searchBar" class="form-control mb-3" placeholder="🔍 Rechercher un PDF..." onkeyup="searchFiles()">

    <!-- Affichage des fichiers -->
    <div class="row">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="col-md-4 file-item">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($row['nom_fichier']) ?></h5>
                        <p class="card-text"><strong>Catégorie :</strong> <?= htmlspecialchars($row['categorie']) ?></p>
                        <a href="<?= htmlspecialchars($row['chemin']) ?>" target="_blank">📂 Ouvrir</a>
                       
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
    function searchFiles() {
        let input = document.getElementById("searchBar").value.toLowerCase();
        let files = document.querySelectorAll(".file-item");

        files.forEach(file => {
            let title = file.querySelector(".card-title").innerText.toLowerCase();
            if (title.includes(input)) {
                file.style.display = "block";
            } else {
                file.style.display = "none";
            }
        });
    }
</script>

</body>
</html>
