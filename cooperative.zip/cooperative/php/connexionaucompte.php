<?php
session_start();
include("connexionbd.php");

if (!isset($_POST['connecter'])) {
    header("Location: connexion.php");
    exit;
}

$nom    = trim($_POST['nom']);
$password = trim($_POST['password']);

$sql = "SELECT * FROM membre WHERE nom = ? AND password = ?";
$req = $bdd->prepare($sql);
$req->execute([$nom, $password]);

$membre = $req->fetch(PDO::FETCH_ASSOC);

if ($membre) {
    // Connexion réussie
    $_SESSION['membre_id'] = $membre['id'];
    $_SESSION['nom'] = $membre['nom'];

    header("Location: pagemembres.php");
    exit;
} else {
    // Échec
    echo "<p style='color:red; text-align:center;'>
            Nom ou numéro incorrect
          </p>";
    echo "<p style='text-align:center;'>
            <a href='connexion.php'>Réessayer</a>
          </p>";
}
