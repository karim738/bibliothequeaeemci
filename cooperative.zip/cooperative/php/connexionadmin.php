<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Connexion Administrateur</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <h2>Connexion Administrateur</h2>
    <p>Veuillez entrer vos identifiants :</p>

    <form action="admin.php" method="post">

        <label>Nom d'utilisateur</label><br>
        <input type="text" name="username" required>
        <br><br>

        <label>Mot de passe</label><br>
        <input type="password" name="password" required>
        <br><br>

        <button type="submit" name="connecter">Se connecter</button>
    </form>

</body>

</html>