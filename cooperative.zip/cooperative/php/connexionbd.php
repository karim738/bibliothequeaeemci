<?php

/**
 * ========================================
 * FICHIER DE CONNEXION À LA BASE DE DONNÉES
 * ========================================
 * 
 * Ce fichier établit la connexion à la base de données MySQL
 * en utilisant PDO (PHP Data Objects) pour plus de sécurité
 * 
 * @author Coopérative
 * @version 2.0 (Corrigée et commentée)
 */

// ===== CONFIGURATION DE LA BASE DE DONNÉES =====

// Nom de la base de données à utiliser
$bd = "cooperative";

// Adresse du serveur MySQL (localhost = serveur local)
$host = "localhost";

// Nom d'utilisateur MySQL
$user = "root";

// Mot de passe MySQL
// ⚠️ ATTENTION : En production, ne JAMAIS mettre le mot de passe en clair dans le code !
// Utiliser plutôt un fichier de configuration séparé (.env) ou des variables d'environnement
$pwd = "";

// ===== TENTATIVE DE CONNEXION À LA BASE DE DONNÉES =====

try {
    /**
     * Création d'une nouvelle instance PDO pour se connecter à MySQL
     * 
     * Paramètres :
     * - DSN (Data Source Name) : "mysql:host=$host;dbname=$bd;charset=utf8"
     *   → Spécifie le type de BD (mysql), l'hôte, le nom de la BD et l'encodage
     * - Nom d'utilisateur : $user
     * - Mot de passe : $pwd
     */
    $bdd = new PDO("mysql:host=$host;dbname=$bd;charset=utf8", $user, $pwd);

    /**
     * Configuration du mode d'erreur de PDO
     * 
     * PDO::ERRMODE_EXCEPTION : Lance une exception en cas d'erreur SQL
     * Cela permet de capturer les erreurs avec try/catch au lieu de vérifier manuellement
     */
    $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /**
     * ✅ AMÉLIORATION : Active le mode d'émulation des requêtes préparées désactivé
     * Cela force PDO à utiliser de vraies requêtes préparées côté serveur (plus sécurisé)
     */
    $bdd->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

    /**
     * ✅ AMÉLIORATION : Définit le mode de récupération par défaut
     * FETCH_ASSOC : Les résultats seront retournés sous forme de tableau associatif
     * (clés = noms des colonnes)
     */
    $bdd->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    /**
     * En cas d'erreur de connexion, on arrête le script et on affiche un message
     * 
     * ⚠️ ATTENTION : En production, ne jamais afficher les détails de l'erreur !
     * Utiliser plutôt un système de logs et afficher un message générique à l'utilisateur
     */

    // En mode développement (affiche l'erreur détaillée)
    die("❌ Erreur de connexion à la base de données : " . $e->getMessage());

    // En mode production (commenter la ligne au-dessus et décommenter celle-ci)
    // error_log("Erreur BD : " . $e->getMessage()); // Enregistre dans les logs
    // die("❌ Erreur de connexion au serveur. Veuillez réessayer plus tard.");
}

/**
 * ✅ CONNEXION RÉUSSIE !
 * La variable $bdd est maintenant disponible dans tous les fichiers qui incluent connexionbd.php
 * Elle peut être utilisée pour exécuter des requêtes SQL de manière sécurisée
 * 
 * Exemple d'utilisation :
 * 
 *   include("connexionbd.php");
 *   $requete = $bdd->prepare("SELECT * FROM membre WHERE id = ?");
 *   $requete->execute([$id_membre]);
 *   $membre = $requete->fetch();
 */
