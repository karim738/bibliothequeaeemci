-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 09 fév. 2026 à 23:12
-- Version du serveur : 8.0.44
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `cooperative`
--

-- --------------------------------------------------------

--
-- Structure de la table `cotisation`
--

DROP TABLE IF EXISTS `cotisation`;
CREATE TABLE IF NOT EXISTS `cotisation` (
  `id_cotisation` int NOT NULL AUTO_INCREMENT,
  `id_membre` int NOT NULL,
  `montant` int NOT NULL,
  `date_cotisation` date NOT NULL,
  `annee` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id_cotisation`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `cotisation`
--

INSERT INTO `cotisation` (`id_cotisation`, `id_membre`, `montant`, `date_cotisation`, `annee`) VALUES
(1, 1, 25000, '2026-01-28', '2026'),
(2, 4, 25000, '2026-01-31', '2026'),
(3, 5, 25000, '2026-02-05', '2026');

-- --------------------------------------------------------

--
-- Structure de la table `membre`
--

DROP TABLE IF EXISTS `membre`;
CREATE TABLE IF NOT EXISTS `membre` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `numero` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `localite` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `domaine` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tonnage` decimal(65,0) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `membre`
--

INSERT INTO `membre` (`id`, `nom`, `numero`, `localite`, `domaine`, `tonnage`, `password`) VALUES
(1, 'karim', '07487548', 'tiassale', 'Café', 2, ''),
(3, 'konan maturin', '05558554', 'broukro', 'Cacao', 3, ''),
(4, 'kouadio yao', '01025685', 'akoupe', 'Cacao', 2, ''),
(5, 'aboua', '05558778', 'alain', 'Café', 1, ''),
(6, 'yameogo pascal', '02024545', 'abokro', 'Cacao', 2, ''),
(7, 'koffi sylvin', '07879887', 'akoupe', 'Café', 2, ''),
(8, 'kone ibrahima', '01025686', 'odiene', 'Cacao', 5, '1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
