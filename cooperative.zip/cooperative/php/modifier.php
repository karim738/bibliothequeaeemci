<?php
/**
 * ========================================
 * PAGE DE MODIFICATION D'UN MEMBRE
 * ========================================
 * 
 * Cette page permet de modifier les informations d'un membre existant
 * 
 * @author Coopérative
 * @version 2.0 (Corrigée et commentée)
 */

// ===== DÉMARRAGE DE LA SESSION =====

/**
 * session_start() : Démarre ou reprend une session PHP
 * Nécessaire pour récupérer les messages et gérer l'authentification
 */
session_start();

// ===== CONNEXION À LA BASE DE DONNÉES =====

/**
 * ⚠️ ERREUR CORRIGÉE : Utilisation du fichier centralisé au lieu de dupliquer la connexion
 */
include("connexionbd.php");

// ===== RÉCUPÉRATION DE L'ID DU MEMBRE À MODIFIER =====

/**
 * Vérification et récupération de l'ID depuis l'URL
 * 
 * isset() : Vérifie si la variable existe
 * !empty() : Vérifie si la variable n'est pas vide
 * (int) : Cast en entier pour sécurité (évite les injections)
 */
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Conversion en entier pour sécurité
    $id = (int) $_GET['id'];
} else {
    /**
     * Si aucun ID n'est fourni, on redirige vers la page d'administration
     */
    $_SESSION['message'] = "⚠️ Aucun membre sélectionné pour modification.";
    $_SESSION['message_type'] = "warning";
    header('Location: gestionadmin.php');
    exit;
}

// ===== RÉCUPÉRATION DES INFORMATIONS DU MEMBRE =====

try {
    /**
     * Requête pour récupérer toutes les infos du membre
     * 
     * ✅ CORRECTION : Utilisation de la table 'membre' au lieu de 'inscription'
     */
    $sql = $bdd->prepare("SELECT * FROM membre WHERE id = ?");
    $sql->execute([$id]);
    
    /**
     * fetch() : Récupère la première ligne (il ne devrait y en avoir qu'une)
     */
    $membre = $sql->fetch();
    
    /**
     * Vérification : Le membre existe-t-il ?
     */
    if (!$membre) {
        $_SESSION['message'] = "❌ Membre introuvable.";
        $_SESSION['message_type'] = "error";
        header('Location: gestionadmin.php');
        exit;
    }
    
} catch (PDOException $e) {
    /**
     * En cas d'erreur lors de la récupération
     */
    $_SESSION['message'] = "❌ Erreur lors de la récupération des données : " . $e->getMessage();
    $_SESSION['message_type'] = "error";
    header('Location: gestionadmin.php');
    exit;
}

// ===== TRAITEMENT DE LA MODIFICATION =====

/**
 * Si le formulaire a été soumis (bouton "modifier" cliqué)
 */
if (isset($_POST['modifier'])) {
    
    // Récupération et sécurisation des données
    $nom = htmlspecialchars($_POST['nom']);
    $localite = htmlspecialchars($_POST['localite']);
    $numero = htmlspecialchars($_POST['numero']);
    $domaine = htmlspecialchars($_POST['domaine']);
    $tonnage = htmlspecialchars($_POST['tonnage']);
    
    // ===== VALIDATION DES DONNÉES =====
    
    $erreurs = [];
    
    // Vérification du nom
    if (trim($nom) === '') {
        $erreurs[] = "Le nom ne peut pas être vide.";
    }
    
    // Vérification du numéro de téléphone
    if (!preg_match('/^[0-9]{8,}$/', $numero)) {
        $erreurs[] = "Le numéro de téléphone doit contenir au moins 8 chiffres.";
    }
    
    // Vérification du tonnage
    if (!is_numeric($tonnage) || $tonnage <= 0) {
        $erreurs[] = "Le tonnage doit être un nombre positif.";
    }
    
    // S'il y a des erreurs
    if (!empty($erreurs)) {
        $_SESSION['message'] = "❌ Erreurs : " . implode(", ", $erreurs);
        $_SESSION['message_type'] = "error";
    } else {
        // ===== MISE À JOUR DANS LA BASE DE DONNÉES =====
        
        try {
            /**
             * Requête UPDATE pour modifier les informations
             * 
             * SET : Définit les nouvelles valeurs
             * WHERE : Condition pour cibler le bon membre
             */
            $sql_update = "UPDATE membre 
                          SET nom = ?, localite = ?, numero = ?, domaine = ?, tonnage = ? 
                          WHERE id = ?";
            
            $stmt = $bdd->prepare($sql_update);
            $stmt->execute([$nom, $localite, $numero, $domaine, $tonnage, $id]);
            
            // Message de succès
            $_SESSION['message'] = "✅ Membre modifié avec succès !";
            $_SESSION['message_type'] = "success";
            
            // Redirection vers la page d'administration
            header('Location: gestionadmin.php');
            exit;
            
        } catch (PDOException $e) {
            $_SESSION['message'] = "❌ Erreur lors de la modification : " . $e->getMessage();
            $_SESSION['message_type'] = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères -->
    <meta charset="UTF-8">
    
    <!-- Configuration responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Lien vers la feuille de style -->
    <link rel="stylesheet" href="../css/style.css">
    
    <!-- Titre de la page -->
    <title>Modification de Membre</title>
</head>

<body>

    <!-- Conteneur principal du formulaire -->
    <div class="container">
        
        <h2>✏️ Formulaire de modification</h2>
        
        <!-- ===== AFFICHAGE DES MESSAGES ===== -->
        <?php 
        /**
         * Si un message existe dans la session, on l'affiche
         */
        if (isset($_SESSION['message'])): 
            $type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';
            
            // Couleurs selon le type de message
            $couleurs = [
                'success' => '#d4edda',
                'error' => '#f8d7da',
                'warning' => '#fff3cd',
                'info' => '#d1ecf1'
            ];
            $couleur = isset($couleurs[$type]) ? $couleurs[$type] : $couleurs['info'];
        ?>
            <div style="background:<?= $couleur ?>; padding:15px; margin:20px 0; border-radius:5px;">
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
        <?php 
            // Suppression du message après affichage
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
        endif; 
        ?>
        
        <!-- Cadre du formulaire -->
        <div id="cadre">
            <!-- 
                Formulaire de modification
                
                method="POST" : Les données sont envoyées en POST (plus sécurisé que GET)
                action="" : Soumet vers la même page
            -->
            <form method="POST" action="">
                
                <!-- ===== CHAMP NOM ===== -->
                <label for="nom">Nom & prénoms :</label>
                <!-- 
                    value="..." : Pré-remplit le champ avec la valeur actuelle
                    required : Champ obligatoire
                -->
                <input type="text" 
                       required 
                       name="nom" 
                       id="nom" 
                       value="<?= htmlspecialchars($membre['nom']) ?>" 
                       placeholder="Nom complet" />
                <br>

                <!-- ===== CHAMP LOCALITÉ ===== -->
                <label for="localite">Localité :</label>
                <input type="text" 
                       required 
                       name="localite" 
                       id="localite" 
                       value="<?= htmlspecialchars($membre['localite']) ?>" 
                       placeholder="Votre ville/village" />
                <br>

                <!-- ===== CHAMP TÉLÉPHONE ===== -->
                <label for="numero">Téléphone :</label>
                <input type="tel" 
                       required 
                       name="numero" 
                       id="numero" 
                       value="<?= htmlspecialchars($membre['numero']) ?>" 
                       placeholder="Ex: 0700000000" />
                <br>

                <!-- ===== CHAMP FILIÈRE ===== -->
                <label for="domaine">Filière :</label>
                <select name="domaine" id="domaine" required>
                    <option value="">Sélectionner la filière</option>
                    
                    <!-- 
                        selected : Pré-sélectionne l'option qui correspond à la valeur actuelle
                        Condition : Si $membre['domaine'] == "Café", alors selected
                    -->
                    <option value="Café" <?= $membre['domaine'] == 'Café' ? 'selected' : '' ?>>Café</option>
                    <option value="Cacao" <?= $membre['domaine'] == 'Cacao' ? 'selected' : '' ?>>Cacao</option>
                    <option value="Café et Cacao" <?= $membre['domaine'] == 'Café et Cacao' ? 'selected' : '' ?>>Café et Cacao</option>
                </select>
                <br>

                <!-- ===== CHAMP TONNAGE ===== -->
                <label for="tonnage">Tonnage annuel (en tonne) :</label>
                <input type="number" 
                       name="tonnage" 
                       id="tonnage" 
                       step="0.01" 
                       value="<?= htmlspecialchars($membre['tonnage']) ?>" 
                       placeholder="Ex: 2.5" 
                       required />
                <br>

                <!-- ===== BOUTONS D'ACTION ===== -->
                
                <!-- Bouton de soumission -->
                <button type="submit" name="modifier" class="btnConnect" style="background:#28a745;">
                    ✅ Enregistrer les modifications
                </button>
                <br><br>
                
                <!-- Lien de retour -->
                <a href="gestionadmin.php" class="lien">← Retour à la gestion</a>
            </form>
        </div>
    </div>

    <!-- ===== CONFIRMATION AVANT SOUMISSION (OPTIONNEL) ===== -->
    <script>
        /**
         * ✅ AMÉLIORATION : Confirmation avant modification
         * 
         * Ajoute un événement sur le formulaire pour demander confirmation
         */
        document.querySelector('form').addEventListener('submit', function(e) {
            // Demande de confirmation
            if (!confirm('Êtes-vous sûr de vouloir modifier ce membre ?')) {
                // Si l'utilisateur clique sur "Annuler"
                e.preventDefault();  // Empêche la soumission du formulaire
            }
        });
    </script>

</body>

</html>
