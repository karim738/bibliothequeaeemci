<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Connexion - Coopérative</title>

</head>

<body>

    <div class="container">
        <h2>Connexion Membre</h2>
        <p>Veuillez entrer vos informations :</p>

        <form action="connexionaucompte.php" method="post">

            <label for="nom">Nom</label>
            <input type="text" id="nom" name="nom" required>

            <label for="password">mot de passe </label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="connecter">
                Se connecter
            </button>

            <a href="index.php" class="lien">Retour à l'accueil</a>

        </form>
    </div>

</body>

</html>