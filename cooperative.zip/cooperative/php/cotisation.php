<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères (UTF-8 pour les accents) -->
    <meta charset="UTF-8">

    <!-- Titre de la page affiché dans l'onglet du navigateur -->
    <title>Formulaire de Cotisation</title>

    <!-- Lien vers le fichier CSS pour le style de la page -->
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <!-- Conteneur principal du formulaire de cotisation -->
    <div class="cotisation-container">

        <!-- Titre principal de la page -->
        <h2>Formulaire de Cotisation</h2>

        <!-- Texte explicatif -->
        <p>Veuillez renseigner les informations de cotisation</p>

        <!-- 
            Formulaire HTML qui enverra les données en POST
            
            ⚠️ ERREUR CORRIGÉE : L'action pointait vers "traitementc.php" qui n'existe pas
            ✅ CORRECTION : Pointe maintenant vers "traitement_cotisation.php"
        -->
        <form method="POST" action="traitement_cotisation.php">

            <!-- ===== SÉLECTION DU MEMBRE ===== -->

            <label>Nom du membre</label>

            <!-- 
                Liste déroulante pour sélectionner un membre
                name="id_membre" : Le nom du champ envoyé au serveur
                required : Champ obligatoire (validation HTML5)
            -->
            <select name="id_membre" id="id_membre" required>
                <option value="">-- Choisir un membre --</option>

                <?php
                /**
                 * ===== CHARGEMENT DE LA LISTE DES MEMBRES DEPUIS LA BD =====
                 * 
                 * On inclut le fichier de connexion pour avoir accès à $bdd
                 */
                include("connexionbd.php");

                /**
                 * ⚠️ ERREUR CORRIGÉE : La requête utilisait "inscription" et "nomcomplet"
                 * ✅ CORRECTION : Utilise maintenant "membre", "id" et "nom"
                 * 
                 * SELECT : Récupère l'ID, le nom et le domaine (filière) de chaque membre
                 * ORDER BY : Trie les résultats par ordre alphabétique de nom
                 */
                $requete = $bdd->query("SELECT id, nom, domaine FROM membre ORDER BY nom");

                /**
                 * fetchAll() : Récupère tous les résultats dans un tableau
                 * Chaque élément du tableau est un membre (tableau associatif)
                 */
                $membres = $requete->fetchAll();

                /**
                 * Boucle à travers tous les membres pour créer les options du select
                 * 
                 * count($membres) : Nombre total de membres
                 * for : Répète le code pour chaque membre (de 0 à count-1)
                 */
                for ($i = 0; $i < count($membres); $i++) {
                    /**
                     * Construction de chaque option
                     * 
                     * value : L'ID du membre (c'est ce qui sera envoyé au serveur)
                     * data-filiere : Attribut personnalisé contenant la filière (pour usage JS si besoin)
                     * Texte affiché : Le nom du membre
                     * 
                     * htmlspecialchars() : Sécurise l'affichage (évite les attaques XSS)
                     */
                    echo '<option value="' . htmlspecialchars($membres[$i]['id']) . '" 
                                  data-filiere="' . htmlspecialchars($membres[$i]['domaine']) . '">
                              ' . htmlspecialchars($membres[$i]['nom']) . '
                          </option>';
                }
                ?>
            </select>

            <!-- ===== ANNÉE DE COTISATION ===== -->

            <label>Année de cotisation</label>

            <!-- 
                Champ de sélection d'année
                
                ✅ AMÉLIORATION : Ajout de ce champ pour préciser l'année
                Par défaut : Année en cours (récupérée avec date('Y'))
            -->
            <select name="annee" required>
                <?php
                /**
                 * Génère les options pour les 3 dernières années et l'année en cours
                 * 
                 * date('Y') : Retourne l'année en cours (ex: 2026)
                 * range() : Crée un tableau des années (ex: [2024, 2025, 2026])
                 */
                $annee_actuelle = date('Y');
                $annees = range($annee_actuelle - 2, $annee_actuelle);

                /**
                 * Boucle pour créer une option pour chaque année
                 */
                foreach ($annees as $annee) {
                    /**
                     * selected : Pré-sélectionne l'année en cours
                     * Condition : Si $annee == $annee_actuelle, ajoute l'attribut "selected"
                     */
                    $selected = ($annee == $annee_actuelle) ? 'selected' : '';
                    echo "<option value='$annee' $selected>$annee</option>";
                }
                ?>
            </select>

            <!-- ===== MONTANT DE LA COTISATION ===== -->

            <label>Montant (FCFA)</label>

            <!-- 
                Champ numérique pour le montant
                
                type="number" : Accepte uniquement des nombres
                name="montant" : Nom du champ pour le traitement
                min="0" : La valeur minimale est 0 (pas de montants négatifs)
                step="1" : Incrémente par pas de 1 (nombres entiers)
                required : Champ obligatoire
                placeholder : Texte d'exemple affiché quand le champ est vide
            -->
            <input type="number"
                name="montant"
                min="0"
                step="1"
                required
                placeholder="Ex: 25000">

            <!-- ===== BOUTON DE SOUMISSION ===== -->

            <!-- 
                Bouton pour envoyer le formulaire
                
                type="submit" : Envoie les données du formulaire
                name="valider" : Nom du bouton (utilisé dans le script PHP pour vérifier la soumission)
            -->
            <button type="submit" name="valider">Enregistrer la cotisation</button>

            <!-- ===== LIENS DE NAVIGATION ===== -->

            <div style="margin-top: 20px; text-align: center;">
                <!-- Lien pour revenir à la page précédente -->
                <a href="dashboard.php" style="color: #007bff; text-decoration: none;">
                    ← Retour au tableau de bord
                </a>
            </div>

        </form>
    </div>

    <!-- 
        ===== SCRIPT JAVASCRIPT OPTIONNEL =====
        Peut être ajouté pour améliorer l'expérience utilisateur
    -->
    <script>
        /**
         * ✅ AMÉLIORATION : Affiche la filière du membre sélectionné
         * 
         * Cela peut aider l'utilisateur à vérifier qu'il a sélectionné le bon membre
         */
        document.getElementById('id_membre').addEventListener('change', function() {
            // Récupère l'option sélectionnée
            var selectedOption = this.options[this.selectedIndex];

            // Récupère la filière depuis l'attribut data-filiere
            var filiere = selectedOption.getAttribute('data-filiere');

            // Affiche la filière (peut être amélioré avec un élément HTML dédié)
            if (filiere) {
                console.log('Filière du membre : ' + filiere);
                // Vous pouvez ajouter un élément pour afficher cette info visuellement
            }
        });
    </script>

</body>

</html>