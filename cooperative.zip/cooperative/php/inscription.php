<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Page Inscription</title>
</head>

<body>
    <div class="container">
        <h2>Formulaire d'inscription</h2>
        <div id="cadre">
            <form method="POST" action="creecompte.php">
                <label for="nom">Nom & prénoms :</label>
                <input type="text" required name="nom" id="nom" placeholder="Nom complet" />
                <br>

                <label for="localite">Localité :</label>
                <input type="text" required name="localite" id="localite" placeholder="Votre ville/village" />
                <br>

                <label for="numero">Téléphone :</label>
                <input type="tel" required name="numero" id="numero" placeholder="Ex: 0700000000" />
                <br>

                <label for="password">Mot de passe :</label>
                <input type="text" required name="password" id="password" placeholder="Votre mot de passe " />
                <br>



                <label for=" domaine">Filière :</label>
                <select name="domaine" id="domaine" required>
                    <option value="">Sélectionner la filière</option>
                    <option value="Café">Café</option>
                    <option value="Cacao">Cacao</option>
                    <option value="Café et Cacao">Café et Cacao</option>
                </select>
                <br>

                <label for="tonnage">Tonnage annuel (en tonne) :</label>
                <input type="number" name="tonnage" id="tonnage" step="0.01" placeholder="Ex: 2.5" required />
                <br>

                <button type="submit" name="valider" id="Envoyer" class="btnConnect">S'inscrire</button>
                <br><br>
                <a href="connexion.php" class="lien">Retour à l'accueil</a>
            </form>
        </div>
    </div>
</body>

</html>