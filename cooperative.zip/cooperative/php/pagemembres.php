<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères -->
    <meta charset="UTF-8">

    <!-- Configuration du viewport pour le responsive design (adaptation mobile) -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Lien vers la feuille de style CSS -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- Titre de la page affiché dans l'onglet du navigateur -->
    <title>Liste des Membres - Coopérative</title>
</head>

<body>

    <!-- Titre principal de la page -->
    <h1>📋 Liste des membres inscrits</h1>

    <?php
    /**
     * ========================================
     * SECTION PHP : RÉCUPÉRATION ET AFFICHAGE DES MEMBRES
     * ========================================
     */

    // ===== INCLUSION DE LA CONNEXION À LA BD =====
    include("connexionbd.php");

    // ===== GESTION DU FILTRE PAR FILIÈRE =====

    /**
     * Récupération du paramètre 'filiere' depuis l'URL
     * 
     * Exemple d'URL : pagemembres.php?filiere=Cacao
     * 
     * isset() : Vérifie si le paramètre existe dans l'URL
     * Opérateur ternaire (? :) : Si existe → valeur, sinon → chaîne vide
     */
    $filtre_filiere = isset($_GET['filiere']) ? $_GET['filiere'] : '';

    // ===== CALCUL DES STATISTIQUES GLOBALES =====

    /**
     * Requête pour obtenir :
     * - COUNT(*) : Nombre total de membres
     * - SUM(CAST(tonnage AS UNSIGNED)) : Somme totale des tonnages
     *   → CAST(...AS UNSIGNED) : Convertit le tonnage en nombre entier non signé
     *   → Nécessaire car tonnage est de type DECIMAL dans la BD
     */
    $stats = $bdd->query("SELECT 
        COUNT(*) as total_membre,
        SUM(CAST(tonnage AS UNSIGNED)) as tonnage_total
        FROM membre 
    ")->fetch();

    // ===== CONSTRUCTION DE LA REQUÊTE AVEC FILTRE =====

    /**
     * On construit dynamiquement la requête SQL selon si un filtre est appliqué ou non
     * 
     * "WHERE 1=1" : Astuce pour simplifier l'ajout de conditions
     * - 1=1 est toujours vrai, donc ne change rien
     * - Permet d'ajouter facilement des "AND" après
     */
    $sql = "SELECT * FROM membre WHERE 1=1";

    /**
     * Si un filtre de filière est défini (et non vide)
     * On ajoute une condition à la requête
     */
    if ($filtre_filiere !== '') {
        /**
         * :filiere : Paramètre nommé (sera remplacé par la vraie valeur)
         * C'est plus lisible que les ? et permet de réutiliser le même paramètre
         */
        $sql .= " AND domaine = :filiere";
    }

    // Tri des résultats par ordre alphabétique de nom
    $sql .= " ORDER BY nom";

    /**
     * Préparation de la requête
     * prepare() : Prépare la requête avec les placeholders
     */
    $stmt = $bdd->prepare($sql);

    /**
     * Si un filtre est appliqué, on lie la valeur au paramètre
     * 
     * bindParam() : Lie une variable PHP à un paramètre de requête SQL
     * - ':filiere' : Nom du paramètre dans la requête
     * - $filtre_filiere : Variable PHP contenant la valeur
     */
    if ($filtre_filiere !== '') {
        $stmt->bindParam(':filiere', $filtre_filiere);
    }

    /**
     * Exécution de la requête préparée
     * À ce moment, les ? ou :param sont remplacés par les vraies valeurs
     */
    $stmt->execute();

    // ===== RÉCUPÉRATION DE LA LISTE DES FILIÈRES =====

    /**
     * Pour le menu déroulant de filtre
     * 
     * DISTINCT : Ne retourne que les valeurs uniques (pas de doublons)
     * Cette requête retourne toutes les filières qui existent dans la table membre
     */
    $filieres = $bdd->query("SELECT DISTINCT domaine FROM membre ORDER BY domaine")->fetchAll();
    ?>

    <!-- ===== AFFICHAGE DES STATISTIQUES ===== -->

    <div class="stats-box" style="background:#f0f7ff; padding:15px; margin:20px 0; border-radius:8px; border-left:4px solid #007bff;">
        <!-- 
            number_format() : Formate un nombre avec séparateurs de milliers
            Exemple : 1234 devient "1,234" (ou "1 234" selon la locale)
        -->
        <strong>📊 Total membres :</strong> <?= number_format($stats['total_membre']) ?> |
        <strong>⚖️ Tonnage total :</strong> <?= number_format($stats['tonnage_total']) ?> tonnes
    </div>

    <!-- ===== SECTION DE FILTRE ===== -->

    <div class="filter-section" style="margin:20px 0; padding:15px; background:white; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1);">

        <!-- 
            Formulaire de filtre
            method="GET" : Les données sont envoyées dans l'URL (visible et bookmarkable)
            action="" : Pointe vers la même page
        -->


        <!-- ===== TABLEAU DES MEMBRES ===== -->

        <table border="1" style="width:100%; border-collapse:collapse; margin:20px 0;">

            <!-- En-tête du tableau -->
            <thead style="background:#007bff; color:white;">
                <tr>
                    <th style="padding:12px;">N°</th>
                    <th style="padding:12px;">Nom & Prénoms</th>
                    <th style="padding:12px;">Téléphone</th>
                    <th style="padding:12px;">Localité</th>
                    <th style="padding:12px;">Filière</th>
                    <th style="padding:12px;">Tonnage annuel (tonnes)</th>
                    <!-- 
                    ⚠️ AMÉLIORATION : Colonne "Montant" retirée du tableau
                    Car les montants sont gérés dans la table cotisation, pas dans membre
                -->
                </tr>
            </thead>

            <!-- Corps du tableau -->
            <tbody>
                <?php
                /**
                 * Variable pour numéroter les lignes
                 * Commence à 1 et s'incrémente à chaque ligne
                 */
                $numero = 1;

                /**
                 * Boucle qui parcourt tous les résultats de la requête
                 * 
                 * while : Tant qu'il y a des résultats à récupérer
                 * $stmt->fetch() : Récupère la ligne suivante
                 * $element : Tableau associatif contenant les données de la ligne
                 */
                while ($element = $stmt->fetch()) {
                    /**
                     * Construction de chaque ligne du tableau
                     * 
                     * Style alternant pour améliorer la lisibilité :
                     * - Lignes paires : fond blanc
                     * - Lignes impaires : fond gris clair
                     * 
                     * $numero % 2 : Modulo 2 (reste de la division par 2)
                     * - Si pair : reste = 0
                     * - Si impair : reste = 1
                     */
                    $style_ligne = ($numero % 2 == 0) ? 'background:#f8f9fa;' : '';

                    echo "<tr style='$style_ligne'>";

                    /**
                     * $numero++ : Affiche $numero puis l'incrémente de 1
                     * Équivalent à : echo $numero; $numero = $numero + 1;
                     */
                    echo "<td style='padding:10px; text-align:center;'>" . $numero++ . "</td>";

                    /**
                     * htmlspecialchars() : Convertit les caractères spéciaux en entités HTML
                     * → Empêche les attaques XSS (injection de code JavaScript malveillant)
                     * 
                     * Exemple : Si le nom contient <script>alert('hack')</script>
                     * → Sera affiché tel quel au lieu d'être exécuté
                     */
                    echo "<td style='padding:10px;'>" . htmlspecialchars($element['nom']) . "</td>";
                    echo "<td style='padding:10px; text-align:center;'>" . htmlspecialchars($element['numero']) . "</td>";
                    echo "<td style='padding:10px;'>" . htmlspecialchars($element['localite']) . "</td>";

                    /**
                     * ✅ AMÉLIORATION : Affichage avec badge coloré pour la filière
                     */
                    $couleur_filiere = ($element['domaine'] == 'Cacao') ? '#6f4e37' : '#7b3f00';
                    echo "<td style='padding:10px;'>
                        <span style='background:$couleur_filiere; color:white; padding:4px 10px; border-radius:12px; font-size:12px;'>
                            " . htmlspecialchars($element['domaine']) . "
                        </span>
                      </td>";

                    /**
                     * Affichage du tonnage avec unité
                     * number_format() ajoute les séparateurs de milliers
                     */
                    echo "<td style='padding:10px; text-align:center;'>" . number_format($element['tonnage'], 2) . " t</td>";

                    echo "</tr>";
                }

                /**
                 * Si aucun membre n'est trouvé (après application du filtre)
                 * On affiche un message dans le tableau
                 */
                if ($numero == 1) {
                    echo "<tr>";
                    echo "<td colspan='6' style='padding:20px; text-align:center; color:#999;'>
                        Aucun membre trouvé" . ($filtre_filiere ? " pour la filière " . htmlspecialchars($filtre_filiere) : "") . ".
                      </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- ===== SECTION BOUTONS D'ACTION ===== -->



</body>

</html>