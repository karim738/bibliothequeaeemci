<?php

/**
 * ========================================
 * TRAITEMENT DE CRÉATION DE COMPTE MEMBRE
 * ========================================
 * 
 * Ce fichier traite les données du formulaire d'inscription
 * et enregistre un nouveau membre dans la base de données
 * 
 * @author Coopérative
 * @version 2.0 (Corrigée et commentée)
 */

// ===== INCLUSION DU FICHIER DE CONNEXION À LA BD =====
// Charge la variable $bdd qui contient la connexion PDO
include("connexionbd.php");

// ===== VÉRIFICATION DE LA SOUMISSION DU FORMULAIRE =====

/**
 * Vérifie si le formulaire a été soumis via le bouton "valider"
 * isset() retourne true si la variable existe et n'est pas null
 */
if (isset($_POST['valider'])) {
    
    // ===== RÉCUPÉRATION ET SÉCURISATION DES DONNÉES =====

    /**
     * htmlspecialchars() convertit les caractères spéciaux en entités HTML
     * Cela empêche les attaques XSS (Cross-Site Scripting)
     * 
     * Exemple : "<script>alert('hack')</script>" devient "&lt;script&gt;alert('hack')&lt;/script&gt;"
     */

    // Récupération du nom complet du membre
    $nom = htmlspecialchars($_POST['nom']);

    // Récupération de la localité (ville/village)
    $localite = htmlspecialchars($_POST['localite']);

    // Récupération du numéro de téléphone
    $numero = htmlspecialchars($_POST['numero']);

    // Récupération du domaine (filière : Café, Cacao, etc.)
    $domaine = htmlspecialchars($_POST['domaine']);

    // Récupération du mot de passe 
    $password = htmlspecialchars($_POST['password']);


    // Récupération du tonnage annuel
    $tonnage = htmlspecialchars($_POST['tonnage']);

    // ===== VALIDATION SUPPLÉMENTAIRE DES DONNÉES =====

    /**
     * ✅ AMÉLIORATION : Validation côté serveur
     * Ne jamais faire confiance aux données du client !
     */
    $erreurs = [];

    // Vérification que le nom n'est pas vide (après suppression des espaces)
    if (trim($nom) === '') {
        $erreurs[] = "Le nom ne peut pas être vide.";
    }

    // Vérification que le numéro de téléphone contient au moins 8 chiffres
    if (!preg_match('/^[0-9]{8,}$/', $numero)) {
        $erreurs[] = "Le numéro de téléphone doit contenir au moins 8 chiffres.";
    }

    // Vérification que le tonnage est un nombre positif
    if (!is_numeric($tonnage) || $tonnage <= 0) {
        $erreurs[] = "Le tonnage doit être un nombre positif.";
    }

    // S'il y a des erreurs, on les affiche et on arrête le traitement
    if (!empty($erreurs)) {
        echo "<div style='background:#ffebee; padding:20px; margin:20px; border-left:4px solid #f44336;'>";
        echo "<h3 style='color:#c62828; margin-top:0;'>❌ Erreurs de validation :</h3>";
        echo "<ul style='color:#c62828;'>";
        foreach ($erreurs as $erreur) {
            echo "<li>" . htmlspecialchars($erreur) . "</li>";
        }
        echo "</ul>";
        echo "<p><a href='inscription.php' style='color:#1976d2;'>← Retour au formulaire</a></p>";
        echo "</div>";
        exit; // Arrête l'exécution du script
    }

    // ===== INSERTION DANS LA BASE DE DONNÉES =====

    try {
        /**
         * Préparation de la requête SQL avec des placeholders (?)
         * Cela empêche les injections SQL
         * 
         * ⚠️ ERREUR CORRIGÉE : Les colonnes 'montant' et 'date_paiement' ont été retirées
         * car elles ne sont pas utilisées lors de l'inscription
         * Ces données sont gérées dans la table 'cotisation'
         */
        $sql = "INSERT INTO membre (nom, numero, localite, domaine,tonnage, password) 
                VALUES (?, ?, ?, ?, ?, ?)";

        /**
         * Préparation de la requête
         * prepare() retourne un objet PDOStatement
         */
        $requete = $bdd->prepare($sql);

        /**
         * Exécution de la requête avec les valeurs
         * L'ordre des valeurs dans le tableau doit correspondre à l'ordre des ? dans la requête
         * 
         * Ordre : nom, numero, localite, domaine, tonnage
         */
        $requete->execute([$nom, $numero, $localite, $domaine, $tonnage, $password]);

        // ===== AFFICHAGE DU MESSAGE DE SUCCÈS =====

        echo "<div style='max-width:600px; margin:50px auto; text-align:center; font-family:Arial, sans-serif;'>";
        echo "<div style='background:#e8f5e9; padding:30px; border-radius:10px; border:2px solid #4caf50;'>";
        echo "<h2 style='color:#2e7d32; margin-top:0;'>✅ Inscription réussie !</h2>";
        echo "<p style='color:#1b5e20; font-size:16px;'>Votre compte a été créé avec succès.</p>";
        echo "<div style='margin:20px 0; padding:15px; background:white; border-radius:5px;'>";
        echo "<strong style='color:#2e7d32;'>Membre enregistré :</strong><br>";
        echo "<span style='color:#424242;'>" . htmlspecialchars($nom) . "</span>";
        echo "</div>";
        echo "<a href='connexion.php' style='display:inline-block; margin-top:20px; padding:12px 30px; background:#4caf50; color:white; text-decoration:none; border-radius:5px; font-weight:bold;'>Retour à l'accueil</a>";
        echo "</div>";
        echo "</div>";
    } catch (PDOException $e) {
        /**
         * En cas d'erreur lors de l'insertion
         * Cela peut arriver si :
         * - La connexion à la BD est perdue
         * - Un champ requis est manquant
         * - Une contrainte d'intégrité est violée
         */

        echo "<div style='max-width:600px; margin:50px auto; font-family:Arial, sans-serif;'>";
        echo "<div style='background:#ffebee; padding:30px; border-radius:10px; border:2px solid #f44336;'>";
        echo "<h2 style='color:#c62828; margin-top:0;'>❌ Erreur lors de l'enregistrement</h2>";

        // ✅ En mode développement (affiche l'erreur détaillée)
        echo "<p style='color:#c62828;'>" . htmlspecialchars($e->getMessage()) . "</p>";

        // En mode production (décommenter et commenter la ligne au-dessus)
        // echo "<p style='color:#c62828;'>Une erreur s'est produite. Veuillez réessayer.</p>";

        echo "<a href='inscription.php' style='display:inline-block; margin-top:20px; padding:12px 30px; background:#f44336; color:white; text-decoration:none; border-radius:5px; font-weight:bold;'>← Retour au formulaire</a>";
        echo "</div>";
        echo "</div>";
    }
} else {
    /**
     * Si quelqu'un accède directement à ce fichier sans soumettre le formulaire
     * On le redirige vers la page d'inscription
     */
    header("Location: inscription.php");
    exit;
}
