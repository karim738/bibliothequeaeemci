<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: gestionadmin.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <title>Administration</title>
</head>

<body>

    <h2>Bienvenue Administrateur</h2>
    <p>Vous êtes connecté avec succès.</p>

    <a href="deconnexionadmin.php">Se déconnecter</a>

</body>

</html>