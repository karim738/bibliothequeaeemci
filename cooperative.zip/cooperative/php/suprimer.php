<?php
/**
 * ========================================
 * SCRIPT DE SUPPRESSION D'UN MEMBRE
 * ========================================
 * 
 * Ce fichier traite la suppression d'un membre de la base de données
 * ⚠️ ATTENTION : La suppression est définitive !
 * 
 * @author Coopérative
 * @version 2.0 (Corrigée et commentée)
 */

// ===== DÉMARRAGE DE LA SESSION =====

/**
 * session_start() : Démarre ou reprend une session PHP
 * Nécessaire pour stocker les messages et gérer l'authentification
 */
session_start();

// ===== CONNEXION À LA BASE DE DONNÉES =====

/**
 * ⚠️ ERREUR CORRIGÉE : Utilisation du fichier centralisé connexionbd.php
 * au lieu de dupliquer la connexion
 */
include("connexionbd.php");

// ===== VÉRIFICATION DE L'ID =====

/**
 * Vérification que l'ID du membre à supprimer est présent dans l'URL
 * 
 * isset() : Vérifie si $_GET['id'] existe
 * !empty() : Vérifie si $_GET['id'] n'est pas vide
 */
if (isset($_GET['id']) && !empty($_GET['id'])) {

    /**
     * Récupération et sécurisation de l'ID
     * 
     * (int) : Cast en entier
     * → Cela convertit automatiquement la valeur en nombre entier
     * → Empêche les injections SQL (ex: "5 OR 1=1" devient 5)
     */
    $id = (int) $_GET['id'];
    
    /**
     * Vérification supplémentaire : L'ID doit être > 0
     * Un ID valide ne peut pas être 0 ou négatif
     */
    if ($id <= 0) {
        $_SESSION['message'] = "❌ ID invalide.";
        $_SESSION['message_type'] = "error";
        header('Location: gestionadmin.php');
        exit;
    }

    try {
        /**
         * ===== VÉRIFICATION : LE MEMBRE EXISTE-T-IL ? =====
         * 
         * Avant de supprimer, on vérifie que le membre existe
         */
        $check = $bdd->prepare("SELECT nom FROM membre WHERE id = ?");
        $check->execute([$id]);
        $membre = $check->fetch();
        
        if (!$membre) {
            /**
             * Si le membre n'existe pas
             */
            $_SESSION['message'] = "❌ Membre introuvable.";
            $_SESSION['message_type'] = "error";
            header('Location: gestionadmin.php');
            exit;
        }
        
        /**
         * ===== SUPPRESSION DU MEMBRE =====
         * 
         * DELETE FROM : Supprime les lignes qui correspondent à la condition
         * WHERE id = ? : Ne supprime que le membre avec cet ID spécifique
         * 
         * ⚠️ IMPORTANT : Grâce à la clé étrangère ON DELETE CASCADE
         * définie dans la base de données, toutes les cotisations
         * associées à ce membre seront automatiquement supprimées
         */
        $sql = $bdd->prepare("DELETE FROM membre WHERE id = ?");
        $resultat = $sql->execute([$id]);

        /**
         * Vérification du résultat de la suppression
         * 
         * $resultat : true si la requête s'est exécutée sans erreur
         * rowCount() : Nombre de lignes affectées (0 si aucune suppression)
         */
        if ($resultat && $sql->rowCount() > 0) {
            /**
             * Suppression réussie
             * 
             * On stocke un message de succès dans la session
             * Ce message sera affiché sur la page de destination
             */
            $_SESSION['message'] = "✅ Membre '" . htmlspecialchars($membre['nom']) . "' supprimé avec succès.";
            $_SESSION['message_type'] = "success";
            
            /**
             * ✅ AMÉLIORATION : Message informatif sur les cotisations
             */
            $_SESSION['message'] .= " Toutes ses cotisations ont également été supprimées.";
            
        } else {
            /**
             * La requête s'est exécutée mais aucune ligne n'a été supprimée
             * Cela peut arriver si l'ID n'existe plus (supprimé entretemps)
             */
            $_SESSION['message'] = "⚠️ Aucun membre n'a été supprimé.";
            $_SESSION['message_type'] = "warning";
        }
        
        /**
         * ===== ENREGISTREMENT DANS UN LOG (OPTIONNEL) =====
         * 
         * ✅ AMÉLIORATION : Traçabilité des suppressions
         * En production, il est recommandé de logger cette action
         */
        error_log("Suppression du membre ID: $id, Nom: " . $membre['nom']);
        
        /**
         * Redirection vers la page d'administration
         * 
         * header('Location: ...') : Redirige le navigateur vers une autre page
         * exit : Arrête l'exécution du script après la redirection
         */
        header('Location: gestionadmin.php');
        exit;
        
    } catch (PDOException $e) {
        /**
         * ===== GESTION DES ERREURS =====
         * 
         * En cas d'erreur lors de la suppression
         * (ex: problème de connexion, contrainte violée, etc.)
         */
        
        /**
         * Stockage du message d'erreur
         * 
         * getMessage() : Récupère le message d'erreur de l'exception
         */
        $_SESSION['message'] = "❌ Erreur lors de la suppression.";
        $_SESSION['message_type'] = "error";
        
        /**
         * ✅ AMÉLIORATION : Logging de l'erreur pour le débogage
         * En production, ne jamais afficher les détails de l'erreur à l'utilisateur
         */
        error_log("Erreur suppression membre ID $id : " . $e->getMessage());
        
        /**
         * Redirection vers la page d'administration
         */
        header('Location: gestionadmin.php');
        exit;
    }
    
} else {
    /**
     * ===== ID MANQUANT =====
     * 
     * Si aucun ID n'a été fourni dans l'URL
     * (ex: accès direct à suprimer.php sans paramètre ?id=...)
     */
    $_SESSION['message'] = "⚠️ ID manquant. Impossible de supprimer le membre.";
    $_SESSION['message_type'] = "warning";
    
    /**
     * Redirection vers la page d'administration
     */
    header('Location: gestionadmin.php');
    exit;
}

/**
 * ===== FIN DU SCRIPT =====
 * 
 * Note : Ce script ne contient pas de HTML car il s'agit d'un script de traitement
 * Toutes les branches se terminent par une redirection avec exit
 * 
 * Cela évite les erreurs "Headers already sent" qui se produisent quand
 * on essaie d'utiliser header() après avoir envoyé du contenu HTML
 */
?>
