<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coopérative Agricole - Café & Cacao</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
</head>

<body class="homepage">

    <!-- Navigation -->
    <nav class="main-nav">
        <div class="nav-container">
            <div class="logo">
                <span class="logo-icon">🌱</span>
                <span class="logo-text">Coopérative<br><strong>Café & Cacao</strong></span>
            </div>
            <ul class="nav-links">
                <li><a href="#accueil" class="nav-link active">Accueil</a></li>
                <li><a href="#services" class="nav-link">Nos Services</a></li>
                <li><a href="#apropos" class="nav-link">À Propos</a></li>
                <li><a href="#contact" class="nav-link">Contact</a></li>
            </ul>
            <div class="nav-actions">
                <a href="connexion.php" class="btn-outline">Connexion</a>
                <a href="inscription.php" class="btn-primary">Inscription</a>
                <a href="connexionadmin.php" class="btn-admin">🔐 Admin</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-background"></div>
        <div class="hero-content">
            <div class="hero-badge">🌍 Cultivons ensemble l'avenir</div>
            <h1 class="hero-title">
                <span class="title-line">Votre partenaire</span>
                <span class="title-line accent">dans la production</span>
                <span class="title-line">de Café & Cacao</span>
            </h1>
            <p class="hero-description">
                Rejoignez une communauté de producteurs passionnés.
                Ensemble, valorisons nos récoltes et développons nos exploitations.
            </p>
            <div class="hero-cta">
                <a href="inscription.php" class="cta-button">
                    <span>Devenir membre</span>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M5 12h14M12 5l7 7-7 7" />
                    </svg>
                </a>
                <a href="#services" class="cta-button-secondary">En savoir plus</a>
            </div>
        </div>

        <!-- Statistiques flottantes -->

        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services-section">
        <div class="section-container">
            <div class="section-header">
                <span class="section-badge">Ce que nous offrons</span>
                <h2 class="section-title">Nos Services</h2>
                <p class="section-description">Des solutions complètes pour accompagner votre développement</p>
            </div>

            <div class="services-grid">
                <div class="service-card">
                    <div class="service-icon">📊</div>
                    <h3 class="service-title">Gestion des cotisations</h3>
                    <p class="service-text">Système transparent et sécurisé pour gérer vos contributions annuelles.</p>
                    <a href="#" class="service-link">En savoir plus →</a>
                </div>

                <div class="service-card featured">
                    <div class="service-badge">Populaire</div>
                    <div class="service-icon">🤝</div>
                    <h3 class="service-title">Réseau de producteurs</h3>
                    <p class="service-text">Connectez-vous avec d'autres producteurs et partagez vos expériences.</p>
                    <a href="pagemembres.php" class="service-link">Voir les membres →</a>
                </div>

                <div class="service-card">
                    <div class="service-icon">📈</div>
                    <h3 class="service-title">Suivi de production</h3>
                    <p class="service-text">Suivez vos tonnages et optimisez votre rendement agricole.</p>
                    <a href="#" class="service-link">Découvrir →</a>
                </div>

                <div class="service-card">
                    <div class="service-icon">💼</div>
                    <h3 class="service-title">Accès aux marchés</h3>
                    <p class="service-text">Bénéficiez de meilleures conditions de vente pour vos récoltes.</p>
                    <a href="#" class="service-link">Explorer →</a>
                </div>

                <div class="service-card">
                    <div class="service-icon">🎓</div>
                    <h3 class="service-title">Formation continue</h3>
                    <p class="service-text">Développez vos compétences avec nos programmes de formation.</p>
                    <a href="#" class="service-link">S'inscrire →</a>
                </div>

                <div class="service-card">
                    <div class="service-icon">🌿</div>
                    <h3 class="service-title">Agriculture durable</h3>
                    <p class="service-text">Adoptez des pratiques respectueuses de l'environnement.</p>
                    <a href="#" class="service-link">En savoir plus →</a>
                </div>
            </div>
        </div>
    </section>

    <!-- À propos Section -->
    <section id="apropos" class="about-section">
        <div class="section-container">
            <div class="about-grid">

                <div class="about-content">
                    <span class="section-badge">Notre histoire</span>
                    <h2 class="section-title">Une coopérative au service des producteurs</h2>
                    <p class="about-text">
                        Depuis plus de 15 ans, notre coopérative accompagne les producteurs de café et de cacao
                        dans leur développement. Nous croyons en la force du collectif et en l'importance de
                        valoriser le travail de chacun.
                    </p>
                    <p class="about-text">
                        Notre mission est simple : offrir aux producteurs les outils et les ressources nécessaires
                        pour prospérer dans un marché en constante évolution. Ensemble, nous sommes plus forts.
                    </p>

                    <div class="about-features">
                        <div class="feature-item">
                            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Transparence totale</span>
                        </div>
                        <div class="feature-item">
                            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Accompagnement personnalisé</span>
                        </div>
                        <div class="feature-item">
                            <svg class="feature-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <span>Prix équitables garantis</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="cta-container">
            <div class="cta-content">
                <h2 class="cta-title">Prêt à nous rejoindre ?</h2>
                <p class="cta-text">
                    Devenez membre de notre coopérative et bénéficiez de tous nos services.
                </p>
                <div class="cta-buttons">
                    <a href="inscription.php" class="cta-btn-primary">
                        S'inscrire maintenant
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M5 12h14M12 5l7 7-7 7" />
                        </svg>
                    </a>
                    <a href="#contact" class="cta-btn-secondary">Nous contacter</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-grid">
                <div class="footer-column">
                    <div class="footer-logo">
                        <span class="logo-icon">🌱</span>
                        <span class="logo-text">Coopérative<br><strong>Café & Cacao</strong></span>
                    </div>
                    <p class="footer-description">
                        Ensemble, cultivons l'avenir de l'agriculture ivoirienne.
                    </p>
                </div>

                <div class="footer-column">
                    <h4 class="footer-title">Navigation</h4>
                    <ul class="footer-links">
                        <li><a href="#accueil">Accueil</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#apropos">À propos</a></li>
                        <li><a href="inscription.php">Inscription</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4 class="footer-title">Espace membre</h4>
                    <ul class="footer-links">
                        <li><a href="connexion.php">Connexion</a></li>
                        <li><a href="pagemembres.php">Liste des membres</a></li>
                        <li><a href="connexionadmin.php">Administration</a></li>
                    </ul>
                </div>

                <div class="footer-column">
                    <h4 class="footer-title">Contact</h4>
                    <ul class="footer-contact">
                        <li>📍 Abidjan, Côte d'Ivoire</li>
                        <li>📞 +225 0759772707</li>
                        <li>✉️ contact@cooperative.ci</li>
                    </ul>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2026 Coopérative Café & Cacao. Tous droits réservés.</p>
            </div>
        </div>
    </footer>

</body>

</html>