<?php
session_start();

if (isset($_POST['connecter'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Identifiants ADMIN (fixes)
    if ($username === "admin" && $password === "1234") {

        // Connexion réussie
        $_SESSION['admin'] = true;

        header("Location: dashboard.php");
        exit;
    } else {
        echo "<p style='color:red; text-align:center;'>
                Identifiants incorrects
              </p>";
        echo "<p style='text-align:center;'>
                <a href='connexionadmin.php'>Réessayer</a>
              </p>";
    }
}
