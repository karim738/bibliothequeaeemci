<?php

/**
 * ========================================
 * TRAITEMENT DES COTISATIONS
 * ========================================
 * 
 * Ce fichier traite les données du formulaire de cotisation
 * et enregistre le paiement dans la base de données
 * 
 * @author Coopérative
 * @version 2.0 (Corrigée et commentée)
 */

// ===== DÉMARRAGE DE LA SESSION =====

/**
 * session_start() : Démarre ou reprend une session PHP
 * 
 * Les sessions permettent de stocker des informations côté serveur
 * qui persistent entre les différentes pages (ex: messages flash, utilisateur connecté)
 * 
 * ⚠️ IMPORTANT : Doit être appelé AVANT tout output HTML
 */
session_start();

// ===== CONNEXION À LA BASE DE DONNÉES =====

/**
 * ⚠️ ERREUR CORRIGÉE : Le code dupliquait la connexion au lieu d'inclure connexionbd.php
 * ✅ CORRECTION : On inclut maintenant le fichier centralisé
 */
include("connexionbd.php");

// ===== RÉCUPÉRATION DES DONNÉES DU FORMULAIRE =====

/**
 * L'opérateur ?? (null coalescing) retourne la valeur de gauche si elle existe
 * sinon retourne la valeur de droite
 * 
 * Exemple : $id_membre = $_POST['id_membre'] ?? null;
 * - Si $_POST['id_membre'] existe et n'est pas null → $id_membre prend cette valeur
 * - Sinon → $id_membre = null
 */

// ID du membre qui paie la cotisation
$id_membre = $_POST['id_membre'] ?? null;

// Montant de la cotisation (par défaut 0 si non fourni)
$montant = $_POST['montant'] ?? 0;

// Année de cotisation (par défaut année en cours)
$annee = $_POST['annee'] ?? date('Y');

// ===== VALIDATION DES DONNÉES =====

/**
 * Vérification 1 : Un membre doit être sélectionné
 * 
 * Si $id_membre est null ou vide, on arrête le traitement
 */
if (!$id_membre) {
    /**
     * $_SESSION['message'] : Stocke un message dans la session
     * Ce message pourra être affiché sur la page suivante
     */
    $_SESSION['message'] = "⚠️ Aucun membre sélectionné.";
    $_SESSION['message_type'] = "warning"; // Type de message (pour le style)

    /**
     * header("Location: ...") : Redirige l'utilisateur vers une autre page
     * exit : Arrête l'exécution du script après la redirection
     */
    header("Location: cotisation.php");
    exit;
}

/**
 * Vérification 2 : Le montant doit être valide
 * 
 * ✅ AMÉLIORATION : Validation du montant
 */
if (!is_numeric($montant) || $montant <= 0) {
    $_SESSION['message'] = "⚠️ Le montant doit être un nombre positif.";
    $_SESSION['message_type'] = "warning";
    header("Location: cotisation.php");
    exit;
}

/**
 * Vérification 3 : L'année doit être valide
 * 
 * ✅ AMÉLIORATION : Validation de l'année
 */
if (!is_numeric($annee) || $annee < 2000 || $annee > date('Y') + 1) {
    $_SESSION['message'] = "⚠️ L'année sélectionnée n'est pas valide.";
    $_SESSION['message_type'] = "warning";
    header("Location: cotisation.php");
    exit;
}

// ===== VÉRIFICATION DES DOUBLONS =====

try {
    /**
     * Avant d'enregistrer, on vérifie si le membre a déjà payé pour cette année
     * 
     * Cette requête préparée cherche une cotisation existante pour :
     * - Ce membre (id_membre)
     * - Cette année (annee)
     */
    $verif = $bdd->prepare("SELECT id_cotisation FROM cotisation WHERE id_membre = ? AND annee = ?");

    /**
     * Exécution de la requête avec les paramètres
     * L'ordre des valeurs doit correspondre à l'ordre des ? dans la requête
     */
    $verif->execute([$id_membre, $annee]);

    /**
     * rowCount() : Retourne le nombre de lignes trouvées
     * 
     * Si > 0 : Une cotisation existe déjà pour ce membre cette année
     */
    if ($verif->rowCount() > 0) {
        /**
         * ⚠️ Le membre a déjà payé pour cette année
         * On enregistre un message et on redirige
         */
        $_SESSION['message'] = "⚠️ Ce membre a déjà payé sa cotisation pour l'année $annee.";
        $_SESSION['message_type'] = "warning";
        header("Location: gestionadmin.php");
        exit;
    }
    
    // ===== ENREGISTREMENT DE LA COTISATION =====

    /**
     * Si on arrive ici, c'est que la cotisation est valide et non dupliquée
     * On peut donc l'enregistrer dans la base de données
     * 
     * INSERT INTO : Ajoute une nouvelle ligne dans la table cotisation
     * NOW() : Fonction MySQL qui retourne la date et l'heure actuelles
     */
    $req = $bdd->prepare("INSERT INTO cotisation (id_membre, montant, annee, date_cotisation) 
                          VALUES (?, ?, ?, NOW())");

    /**
     * Exécution de l'insertion avec les valeurs
     * Ordre : id_membre, montant, annee
     */
    $req->execute([$id_membre, $montant, $annee]);
    
    // ===== RÉCUPÉRATION DES INFORMATIONS DU MEMBRE =====

    /**
     * ✅ AMÉLIORATION : On récupère le nom du membre pour l'afficher dans le message
     * Cela rend le message de confirmation plus personnalisé
     */
    $membre_info = $bdd->prepare("SELECT nom FROM membre WHERE id = ?");
    $membre_info->execute([$id_membre]);
    $membre = $membre_info->fetch();

    /**
     * Message de succès stocké dans la session
     * Il sera affiché sur la page de destination
     */
    if ($membre) {
        $_SESSION['message'] = "✅ Cotisation de " . number_format($montant) . " FCFA enregistrée avec succès pour " . $membre['nom'] . " (année $annee) !";
    } else {
        $_SESSION['message'] = "✅ Cotisation enregistrée avec succès !";
    }

    $_SESSION['message_type'] = "success";

    /**
     * Redirection vers la page de gestion admin
     * Le message sera affiché là-bas
     */
    header("Location: gestionadmin.php");
    exit;
} catch (PDOException $e) {
    /**
     * ===== GESTION DES ERREURS =====
     * 
     * Si une erreur se produit lors de l'accès à la BD
     * (connexion perdue, contrainte violée, etc.)
     */

    // Enregistrement du message d'erreur dans la session
    $_SESSION['message'] = "❌ Erreur lors de l'enregistrement de la cotisation.";
    $_SESSION['message_type'] = "error";

    /**
     * ✅ En mode développement : On peut logger l'erreur complète
     * Cela aide au débogage sans exposer les détails à l'utilisateur
     */
    error_log("Erreur cotisation : " . $e->getMessage());

    // Redirection vers la page de cotisation
    header("Location: cotisation.php");
    exit;
}

/**
 * ===== FIN DU TRAITEMENT =====
 * 
 * Note : Toutes les branches de ce script se terminent par une redirection
 * Il n'y a donc jamais de contenu HTML affiché directement
 * 
 * Cela évite les erreurs "Headers already sent" qui se produisent quand
 * on essaie de rediriger après avoir envoyé du HTML
 */
