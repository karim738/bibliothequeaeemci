<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères -->
    <meta charset="UTF-8">
    
    <!-- Configuration responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Lien vers la feuille de style -->
    <link rel="stylesheet" href="../css/style.css">
    
    <!-- Titre de la page -->
    <title>Liste des Cotisations</title>
    
    <!-- ===== STYLES CSS INTÉGRÉS ===== -->
    <style>
        /* Conteneur des cartes statistiques */
        .stats-container {
            display: flex;
            gap: 20px;
            margin: 20px 0;
            flex-wrap: wrap;  /* Passage à la ligne si nécessaire */
        }

        /* Carte de statistique individuelle */
        .stat-card {
            background: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            flex: 1;              /* Prend l'espace disponible */
            min-width: 200px;     /* Largeur minimale */
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #333;
            font-size: 14px;
        }

        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
        }

        /* Section de filtre */
        .filter-section {
            background: #f9f9f9;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
        }

        .filter-section form {
            display: flex;
            gap: 10px;
            align-items: end;  /* Alignement en bas */
            flex-wrap: wrap;
        }

        .filter-group {
            display: flex;
            flex-direction: column;  /* Disposition verticale */
        }

        .filter-group label {
            margin-bottom: 5px;
            font-weight: bold;
        }

        .filter-group select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .btn-filter {
            padding: 8px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .btn-filter:hover {
            background: #0056b3;
        }

        /* Styles pour les statuts */
        .status-paye {
            color: green;
            font-weight: bold;
        }

        .status-impaye {
            color: red;
            font-weight: bold;
        }

        /* Style du tableau */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th {
            background: #007bff;
            color: white;
            padding: 12px;
            text-align: left;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background: #f5f5f5;
        }
    </style>
</head>

<body>
    <h2>📋 Liste des cotisations</h2>

    <?php
    /**
     * ========================================
     * SECTION PHP : RÉCUPÉRATION DES COTISATIONS
     * ========================================
     */
    
    // Inclusion de la connexion à la BD
    include("connexionbd.php");

    // ===== RÉCUPÉRATION DES FILTRES =====
    
    /**
     * Récupération des paramètres de filtrage depuis l'URL
     * 
     * isset() : Vérifie si la variable existe dans $_GET
     * Opérateur ternaire : Si existe → valeur, sinon → chaîne vide
     */
    $filtre_statut = isset($_GET['statut']) ? $_GET['statut'] : '';
    $filtre_filiere = isset($_GET['filiere']) ? $_GET['filiere'] : '';

    // ===== STATISTIQUES GLOBALES =====
    
    /**
     * Requête pour calculer les statistiques des cotisations
     * 
     * COUNT(*) : Compte toutes les cotisations
     * SUM(montant) : Somme de tous les montants
     * CASE WHEN : Condition pour catégoriser
     * 
     * ✅ AMÉLIORATION : Utilisation de la vraie table cotisation
     */
    $stats_query = $bdd->query("SELECT 
        COUNT(*) as total_cotisation,
        SUM(montant) as total_montant,
        SUM(CASE WHEN montant >= 25000 THEN 1 ELSE 0 END) as total_payes,
        SUM(CASE WHEN montant < 25000 THEN 1 ELSE 0 END) as total_impayes,
        SUM(CASE WHEN montant >= 25000 THEN montant ELSE 0 END) as montant_payes,
        SUM(CASE WHEN montant < 25000 THEN montant ELSE 0 END) as montant_impayes
        FROM cotisation");
    $stats = $stats_query->fetch();

    // ===== RÉCUPÉRATION DES FILIÈRES DISPONIBLES =====
    
    /**
     * DISTINCT : Ne retourne que les valeurs uniques
     * Cette requête récupère toutes les filières existantes dans la table membre
     */
    $filieres_query = $bdd->query("SELECT DISTINCT domaine FROM membre ORDER BY domaine");
    $filieres = $filieres_query->fetchAll();
    ?>

    <!-- ===== AFFICHAGE DES STATISTIQUES ===== -->
    <div class="stats-container">
        
        <!-- Carte 1 : Nombre total de cotisations -->
        <div class="stat-card">
            <h3>Total des cotisations</h3>
            <div class="value"><?= number_format($stats['total_cotisation']) ?></div>
        </div>
        
        <!-- Carte 2 : Montant total collecté -->
        <div class="stat-card">
            <h3>Montant total collecté</h3>
            <div class="value"><?= number_format($stats['total_montant']) ?> FCFA</div>
        </div>
        
        <!-- Carte 3 : Membres à jour -->
        <div class="stat-card">
            <h3>Membres à jour (≥25000)</h3>
            <div class="value" style="color: green;"><?= number_format($stats['total_payes']) ?></div>
            <small><?= number_format($stats['montant_payes']) ?> FCFA</small>
        </div>
        
        <!-- Carte 4 : Membres en retard -->
        <div class="stat-card">
            <h3>Membres en retard (<25000)</h3>
            <div class="value" style="color: red;"><?= number_format($stats['total_impayes']) ?></div>
            <small><?= number_format($stats['montant_impayes']) ?> FCFA</small>
        </div>
    </div>

    <!-- ===== SECTION DE FILTRAGE ===== -->
    <div class="filter-section">
        <!-- Formulaire de filtre -->
        <form method="GET" action="">
            
            <!-- Filtre par statut -->
            <div class="filter-group">
                <label>Statut</label>
                <select name="statut">
                    <option value="">-- Tous --</option>
                    <!-- 
                        selected : Pré-sélectionne l'option si elle correspond au filtre actuel
                    -->
                    <option value="Payé" <?= $filtre_statut == 'Payé' ? 'selected' : '' ?>>Payé</option>
                    <option value="Impayé" <?= $filtre_statut == 'Impayé' ? 'selected' : '' ?>>Impayé</option>
                </select>
            </div>
            
            <!-- Filtre par filière -->
            <div class="filter-group">
                <label>Filière</label>
                <select name="filiere">
                    <option value="">-- Toutes --</option>
                    <?php foreach ($filieres as $filiere): ?>
                        <option value="<?= htmlspecialchars($filiere['domaine']) ?>"
                            <?= $filtre_filiere == $filiere['domaine'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($filiere['domaine']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Boutons d'action -->
            <button type="submit" class="btn-filter">Filtrer</button>
            <a href="listecotisation.php" class="btn-filter" style="background:#6c757d;">Réinitialiser</a>
        </form>
    </div>

    <!-- ===== TABLEAU DES COTISATIONS ===== -->
    <table border="1">
        <thead>
            <tr>
                <th>Nom complet</th>
                <th>Téléphone</th>
                <th>Filière</th>
                <th>Année</th>
                <th>Montant</th>
                <th>Date de paiement</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <?php
            /**
             * ========================================
             * CONSTRUCTION DE LA REQUÊTE AVEC JOINTURE
             * ========================================
             * 
             * ⚠️ ERREUR CORRIGÉE : Utilisation d'une vraie jointure avec la table membre
             * pour récupérer les informations complètes
             */
            
            // Construction dynamique de la requête SQL
            $sql = "SELECT 
                        c.id_cotisation,
                        c.montant,
                        c.date_cotisation,
                        c.annee,
                        m.nom,
                        m.numero,
                        m.domaine
                    FROM cotisation c
                    INNER JOIN membre m ON c.id_membre = m.id
                    WHERE 1=1";
            
            $params = [];

            // ===== AJOUT DU FILTRE DE STATUT =====
            
            /**
             * Si un filtre de statut est sélectionné
             * On ajoute une condition à la requête
             */
            if ($filtre_statut == 'Payé') {
                $sql .= " AND c.montant >= 25000";
            } elseif ($filtre_statut == 'Impayé') {
                $sql .= " AND c.montant < 25000";
            }

            // ===== AJOUT DU FILTRE DE FILIÈRE =====
            
            /**
             * Si un filtre de filière est sélectionné
             */
            if ($filtre_filiere !== '') {
                $sql .= " AND m.domaine = :filiere";
                $params['filiere'] = $filtre_filiere;
            }

            // Tri par date décroissante (plus récentes en premier)
            $sql .= " ORDER BY c.date_cotisation DESC";

            /**
             * Préparation et exécution de la requête
             */
            $requete = $bdd->prepare($sql);
            $requete->execute($params);
            $listcotisation = $requete->fetchAll();

            /**
             * ========================================
             * AFFICHAGE DES RÉSULTATS
             * ========================================
             */
            
            // Vérification : Y a-t-il des cotisations ?
            if ($listcotisation && count($listcotisation) > 0) {
                // Variable pour calculer le total affiché
                $total_affiche = 0;

                // Boucle à travers chaque cotisation
                foreach ($listcotisation as $cotisation) {
                    
                    /**
                     * Détermination du statut basé sur le montant
                     * 
                     * ✅ AMÉLIORATION : Seuil cohérent à 25000 FCFA
                     */
                    if ($cotisation['montant'] >= 25000) {
                        $statut = 'Payé';
                        $classe_statut = 'status-paye';
                    } else {
                        $statut = 'Impayé';
                        $classe_statut = 'status-impaye';
                    }

                    // Ajout au total affiché
                    $total_affiche += $cotisation['montant'];

                    /**
                     * Affichage d'une ligne du tableau
                     */
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($cotisation['nom']) . "</td>";
                    echo "<td>" . htmlspecialchars($cotisation['numero']) . "</td>";
                    echo "<td>" . htmlspecialchars($cotisation['domaine']) . "</td>";
                    echo "<td>" . htmlspecialchars($cotisation['annee']) . "</td>";
                    echo "<td>" . number_format($cotisation['montant']) . " FCFA</td>";
                    echo "<td>" . htmlspecialchars($cotisation['date_cotisation']) . "</td>";
                    echo "<td class='$classe_statut'>" . $statut . "</td>";
                    echo "</tr>";
                }

                /**
                 * ===== LIGNE DE TOTAL =====
                 * 
                 * Affiche le total des montants filtrés
                 */
                echo "<tr style='background: #e9ecef; font-weight: bold;'>";
                echo "<td colspan='4'>TOTAL (filtré)</td>";
                echo "<td>" . number_format($total_affiche) . " FCFA</td>";
                echo "<td colspan='2'></td>";
                echo "</tr>";
                
            } else {
                /**
                 * Si aucune cotisation n'est trouvée
                 */
                echo "<tr><td colspan='7' style='text-align: center; padding:20px; color:#999;'>
                        Aucune cotisation trouvée";
                
                // Message plus précis si des filtres sont appliqués
                if ($filtre_statut || $filtre_filiere) {
                    echo " avec les filtres sélectionnés";
                }
                
                echo "</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- ===== BOUTONS DE NAVIGATION ===== -->
    <div style="margin-top: 30px; text-align: center;">
        <a href="dashboard.php" style="display:inline-block; padding:12px 25px; background:#007bff; color:white; text-decoration:none; border-radius:5px; font-weight:bold; margin:5px;">
            📊 Retour au tableau de bord
        </a>
        <a href="cotisation.php" style="display:inline-block; padding:12px 25px; background:#28a745; color:white; text-decoration:none; border-radius:5px; font-weight:bold; margin:5px;">
            ➕ Nouvelle cotisation
        </a>
    </div>

</body>

</html>
