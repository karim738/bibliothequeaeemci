<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères -->
    <meta charset="UTF-8">

    <!-- Configuration responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Lien vers la feuille de style -->
    <link rel="stylesheet" href="../css/style.css">

    <!-- Titre de la page -->
    <title>Statut des Paiements</title>

    <!-- ===== STYLES CSS POUR LES ONGLETS ET BOUTONS D'ACTION ===== -->
    <style>
        /* Style des onglets */
        .tabs {
            display: flex;
            gap: 10px;
            margin: 20px 0;
            border-bottom: 2px solid #ddd;
        }

        .tab {
            padding: 12px 24px;
            background: #f5f5f5;
            border: none;
            border-radius: 5px 5px 0 0;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }

        .tab:hover {
            background: #e0e0e0;
        }

        .tab.active {
            background: #007bff;
            color: white;
        }

        /* Contenu des onglets */
        .tab-content {
            display: none;
            /* Caché par défaut */
            padding: 20px;
            background: white;
            border-radius: 0 5px 5px 5px;
        }

        .tab-content.active {
            display: block;
            /* Affiché quand actif */
        }

        /* Badges de statut */
        .status-badge {
            padding: 5px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }

        .badge-paye {
            background: #d4edda;
            color: #155724;
        }

        .badge-impaye {
            background: #f8d7da;
            color: #721c24;
        }

        /* Boîte de résumé */
        .summary-box {
            background: #f0f7ff;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #007bff;
        }

        .summary-box h3 {
            margin-top: 0;
            color: #007bff;
        }

        .summary-box p {
            margin: 10px 0;
            font-size: 16px;
        }

        /* Style du tableau */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table th {
            background: #007bff;
            color: white;
            padding: 12px;
            text-align: left;
        }

        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }

        table tr:hover {
            background: #f5f5f5;
        }

        /* Section de filtre */
        .filter-section {
            background: #f9f9f9;
            padding: 15px;
            margin: 20px 0;
            border-radius: 8px;
        }

        /* ===== STYLES POUR LES BOUTONS D'ACTION ===== */

        /* Conteneur des boutons d'action */
        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center;
        }

        /* Bouton général */
        .btn-action {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
        }

        /* Bouton Modifier (bleu) */
        .btn-modifier {
            background: #17a2b8;
            color: white;
        }

        .btn-modifier:hover {
            background: #138496;
            transform: translateY(-2px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        /* Bouton Supprimer (rouge) */
        .btn-supprimer {
            background: #dc3545;
            color: white;
        }

        .btn-supprimer:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        /* Icônes des boutons (unicode) */
        .icon-edit::before {
            content: "✏️";
        }

        .icon-delete::before {
            content: "🗑️";
        }

        /* Message d'alerte (session) */
        .alert {
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
            font-weight: bold;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .alert-warning {
            background: #fff3cd;
            color: #856404;
            border-left: 4px solid #ffc107;
        }
    </style>
</head>

<body>
    <h2>📊 Statut des cotisations par membre</h2>

    <?php
    /**
     * ========================================
     * SECTION PHP : RÉCUPÉRATION DU STATUT DES MEMBRES
     * ========================================
     */
    
    // ===== DÉMARRAGE DE LA SESSION =====

    /**
     * session_start() : Démarre ou reprend une session PHP
     * Nécessaire pour afficher les messages de confirmation/erreur
     * après modification ou suppression
     */


    // Inclusion de la connexion à la BD
    include("connexionbd.php");

    // ===== AFFICHAGE DES MESSAGES DE SESSION =====

    /**
     * Si un message existe dans la session (après modification/suppression)
     * On l'affiche puis on le supprime
     */
    if (isset($_SESSION['message'])) {
        $type = isset($_SESSION['message_type']) ? $_SESSION['message_type'] : 'info';
        $classe_alert = 'alert-' . $type;

        echo "<div class='alert $classe_alert'>";
        echo htmlspecialchars($_SESSION['message']);
        echo "</div>";

        // Suppression du message après affichage
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }

    // ===== RÉCUPÉRATION DU FILTRE =====

    /**
     * Récupération du paramètre de filière depuis l'URL
     */
    $filtre_filiere = isset($_GET['filiere']) ? $_GET['filiere'] : '';

    // ===== RÉCUPÉRATION DE TOUTES LES FILIÈRES =====

    /**
     * Pour le menu déroulant de filtre
     */
    $filieres_query = $bdd->query("SELECT DISTINCT domaine FROM membre ORDER BY domaine");
    $filieres = $filieres_query->fetchAll();

    // ===== REQUÊTE POUR LES MEMBRES AYANT PAYÉ =====

    /**
     * Récupère les membres dont le total des cotisations est ≥ 25000 FCFA
     * 
     * ⚠️ IMPORTANT : On récupère l'ID pour les boutons Modifier/Supprimer
     */
    $sql_payes = "SELECT 
                    m.id,
                    m.nom,
                    m.numero,
                    m.localite,
                    m.domaine,
                    COALESCE(SUM(c.montant), 0) as total_verse,
                    MAX(c.date_cotisation) as derniere_cotisation
                  FROM membre m
                  LEFT JOIN cotisation c ON m.id = c.id_membre
                  WHERE 1=1";

    // Ajout du filtre de filière si nécessaire
    if ($filtre_filiere !== '') {
        $sql_payes .= " AND m.domaine = :filiere";
    }

    // Groupement et filtre sur le total (HAVING)
    $sql_payes .= " GROUP BY m.id, m.nom, m.numero, m.localite, m.domaine
                    HAVING COALESCE(SUM(c.montant), 0) >= 25000
                    ORDER BY m.nom";

    /**
     * Préparation et exécution de la requête
     */
    $stmt_payes = $bdd->prepare($sql_payes);
    if ($filtre_filiere !== '') {
        $stmt_payes->bindParam(':filiere', $filtre_filiere);
    }
    $stmt_payes->execute();
    $membres_payes = $stmt_payes->fetchAll();

    // ===== REQUÊTE POUR LES MEMBRES N'AYANT PAS PAYÉ =====

    /**
     * Récupère les membres dont le total des cotisations est < 25000 FCFA
     * Ou qui n'ont jamais payé (total = 0)
     */
    $sql_impayes = "SELECT 
                        m.id,
                        m.nom,
                        m.numero,
                        m.localite,
                        m.domaine,
                        COALESCE(SUM(c.montant), 0) as total_verse,
                        MAX(c.date_cotisation) as derniere_cotisation
                    FROM membre m
                    LEFT JOIN cotisation c ON m.id = c.id_membre
                    WHERE 1=1";

    // Ajout du filtre de filière si nécessaire
    if ($filtre_filiere !== '') {
        $sql_impayes .= " AND m.domaine = :filiere";
    }

    // Groupement et filtre sur le total (HAVING)
    $sql_impayes .= " GROUP BY m.id, m.nom, m.numero, m.localite, m.domaine
                      HAVING COALESCE(SUM(c.montant), 0) < 25000
                      ORDER BY m.nom";

    /**
     * Préparation et exécution de la requête
     */
    $stmt_impayes = $bdd->prepare($sql_impayes);
    if ($filtre_filiere !== '') {
        $stmt_impayes->bindParam(':filiere', $filtre_filiere);
    }
    $stmt_impayes->execute();
    $membres_impayes = $stmt_impayes->fetchAll();

    // ===== CALCUL DES TOTAUX =====

    /**
     * Nombre de membres dans chaque catégorie
     * count() : Retourne le nombre d'éléments dans le tableau
     */
    $total_payes = count($membres_payes);
    $total_impayes = count($membres_impayes);
    ?>

    <!-- ===== SECTION DE FILTRE PAR FILIÈRE ===== -->
    <div class="filter-section">
        <form method="GET" action="">
            <label><strong>🔍 Filtrer par filière :</strong></label>
            <!-- 
                onchange="this.form.submit()" : Soumet automatiquement le formulaire
                dès qu'on change la sélection
            -->
            <select name="filiere" onchange="this.form.submit()" style="padding:8px; border-radius:4px; border:1px solid #ddd;">
                <option value="">-- Toutes les filières --</option>
                <?php foreach ($filieres as $filiere): ?>
                    <option value="<?= htmlspecialchars($filiere['domaine']) ?>"
                        <?= $filtre_filiere == $filiere['domaine'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($filiere['domaine']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <!-- Bouton pour réinitialiser le filtre -->
            <?php if ($filtre_filiere !== ''): ?>
                <a href="statut_paiements.php" style="margin-left:10px; padding:8px 15px; background:#6c757d; color:white; text-decoration:none; border-radius:4px;">
                    ✕ Réinitialiser
                </a>
            <?php endif; ?>
        </form>
    </div>

    <!-- ===== BOÎTE DE RÉSUMÉ ===== -->
    <div class="summary-box">
        <h3>📈 Résumé</h3>
        <p><strong>✅ Membres à jour (≥ 25 000 FCFA) :</strong> <span style="color:#28a745; font-size:20px;"><?= $total_payes ?></span></p>
        <p><strong>⚠️ Membres en retard (< 25 000 FCFA) :</strong> <span style="color:#dc3545; font-size:20px;"><?= $total_impayes ?></span></p>
        <p><strong>👥 Total membres<?= $filtre_filiere ? ' (' . htmlspecialchars($filtre_filiere) . ')' : '' ?> :</strong> <span style="color:#007bff; font-size:20px;"><?= $total_payes + $total_impayes ?></span></p>

        <?php
        /**
         * Calcul du pourcentage de membres à jour
         */
        $total_general = $total_payes + $total_impayes;
        if ($total_general > 0) {
            $pourcentage_payes = ($total_payes / $total_general) * 100;
            echo "<p><strong>📊 Taux de paiement :</strong> <span style='color:#17a2b8; font-size:20px;'>" . number_format($pourcentage_payes, 1) . "%</span></p>";
        }
        ?>
    </div>

    <!-- ===== SYSTÈME D'ONGLETS ===== -->
    <div class="tabs">
        <!-- 
            Bouton onglet 1 : Membres à jour
            onclick : Appelle la fonction JavaScript showTab()
            class="active" : Onglet actif par défaut
        -->
        <button class="tab active" onclick="showTab('payes')">
            ✅ Membres à jour (<?= $total_payes ?>)
        </button>

        <!-- Bouton onglet 2 : Membres en retard -->
        <button class="tab" onclick="showTab('impayes')">
            ⚠️ Membres en retard (<?= $total_impayes ?>)
        </button>
    </div>

    <!-- ===== CONTENU ONGLET 1 : MEMBRES AYANT PAYÉ ===== -->
    <div id="payes" class="tab-content active">
        <h3>✅ Membres ayant payé leurs cotisations (≥ 25 000 FCFA)</h3>

        <table border="1">
            <thead>
                <tr>
                    <th>N°</th>
                    <th>Nom complet</th>
                    <th>Téléphone</th>
                    <th>Localité</th>
                    <th>Filière</th>
                    <th>Total versé</th>
                    <th>Dernière cotisation</th>
                    <th>Statut</th>
                    <!-- ✅ NOUVELLE COLONNE : Actions -->
                    <th style="text-align: center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($total_payes > 0): ?>
                    <?php
                    /**
                     * Compteur pour numéroter les lignes
                     */
                    $i = 1;

                    /**
                     * Boucle à travers tous les membres à jour
                     */
                    foreach ($membres_payes as $membre):
                    ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($membre['nom']) ?></td>
                            <td><?= htmlspecialchars($membre['numero']) ?></td>
                            <td><?= htmlspecialchars($membre['localite']) ?></td>
                            <td><?= htmlspecialchars($membre['domaine']) ?></td>
                            <td><strong style="color:green;"><?= number_format($membre['total_verse']) ?> FCFA</strong></td>
                            <td><?= $membre['derniere_cotisation'] ? htmlspecialchars($membre['derniere_cotisation']) : 'N/A' ?></td>
                            <td><span class="status-badge badge-paye">À jour</span></td>

                            <!-- ===== COLONNE ACTIONS : BOUTONS MODIFIER/SUPPRIMER ===== -->
                            <td>
                                <div class="action-buttons">
                                    <!-- 
                                        Bouton Modifier
                                        href="modifier.php?id=..." : Envoie l'ID du membre en paramètre GET
                                    -->
                                    <a href="modifier.php?id=<?= $membre['id'] ?>"
                                        class="btn-action btn-modifier"
                                        title="Modifier les informations de <?= htmlspecialchars($membre['nom']) ?>">
                                        <span class="icon-edit"></span>
                                        Modifier
                                    </a>

                                    <!-- 
                                        Bouton Supprimer
                                        onclick : Confirmation JavaScript avant suppression
                                        Si l'utilisateur confirme → redirection vers suprimer.php
                                        Sinon → return false annule la redirection
                                    -->
                                    <a href="suprimer.php?id=<?= $membre['id'] ?>"
                                        class="btn-action btn-supprimer"
                                        title="Supprimer <?= htmlspecialchars($membre['nom']) ?>"
                                        onclick="return confirm('⚠️ ATTENTION !\n\nÊtes-vous sûr de vouloir supprimer le membre :\n\n<?= htmlspecialchars($membre['nom']) ?> ?\n\nCette action est irréversible et supprimera également toutes ses cotisations.');">
                                        <span class="icon-delete"></span>
                                        Supprimer
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding:20px; color:#999;">
                            Aucun membre à jour pour le moment
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- ===== CONTENU ONGLET 2 : MEMBRES N'AYANT PAS PAYÉ ===== -->
    <div id="impayes" class="tab-content">
        <h3>⚠️ Membres en retard de paiement (< 25 000 FCFA)</h3>

                <table border="1">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Nom complet</th>
                            <th>Téléphone</th>
                            <th>Localité</th>
                            <th>Filière</th>
                            <th>Total versé</th>
                            <th>Reste à payer</th>
                            <th>Dernière cotisation</th>
                            <th>Statut</th>
                            <!-- ✅ NOUVELLE COLONNE : Actions -->
                            <th style="text-align: center;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($total_impayes > 0): ?>
                            <?php
                            /**
                             * Compteur pour numéroter les lignes
                             */
                            $i = 1;

                            /**
                             * Boucle à travers tous les membres en retard
                             */
                            foreach ($membres_impayes as $membre):
                                /**
                                 * Calcul du reste à payer
                                 * Cotisation complète = 25000 FCFA
                                 */
                                $reste = 25000 - $membre['total_verse'];
                            ?>
                                <tr>
                                    <td><?= $i++ ?></td>
                                    <td><?= htmlspecialchars($membre['nom']) ?></td>
                                    <td><?= htmlspecialchars($membre['numero']) ?></td>
                                    <td><?= htmlspecialchars($membre['localite']) ?></td>
                                    <td><?= htmlspecialchars($membre['domaine']) ?></td>
                                    <td><?= number_format($membre['total_verse']) ?> FCFA</td>
                                    <td><strong style="color: red;"><?= number_format($reste) ?> FCFA</strong></td>
                                    <td><?= $membre['derniere_cotisation'] ? htmlspecialchars($membre['derniere_cotisation']) : 'Aucune' ?></td>
                                    <td><span class="status-badge badge-impaye">En retard</span></td>

                                    <!-- ===== COLONNE ACTIONS : BOUTONS MODIFIER/SUPPRIMER ===== -->
                                    <td>
                                        <div class="action-buttons">
                                            <!-- Bouton Modifier -->
                                            <a href="modifier.php?id=<?= $membre['id'] ?>"
                                                class="btn-action btn-modifier"
                                                title="Modifier les informations de <?= htmlspecialchars($membre['nom']) ?>">
                                                <span class="icon-edit"></span>
                                                Modifier
                                            </a>

                                            <!-- Bouton Supprimer -->
                                            <a href="suprimer.php?id=<?= $membre['id'] ?>"
                                                class="btn-action btn-supprimer"
                                                title="Supprimer <?= htmlspecialchars($membre['nom']) ?>"
                                                onclick="return confirm('⚠️ ATTENTION !\n\nÊtes-vous sûr de vouloir supprimer le membre :\n\n<?= htmlspecialchars($membre['nom']) ?> ?\n\nCette action est irréversible et supprimera également toutes ses cotisations.');">
                                                <span class="icon-delete"></span>
                                                Supprimer
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" style="text-align: center; padding:20px; color:#28a745;">
                                    🎉 Tous les membres sont à jour !
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
    </div>

    <!-- ===== BOUTONS DE NAVIGATION ===== -->
    <div style="margin-top: 30px; text-align: center;">
        <a href="dashboard.php" style="display:inline-block; padding:12px 25px; background:#007bff; color:white; text-decoration:none; border-radius:5px; font-weight:bold; margin:5px;">
            📊 Retour au tableau de bord
        </a>
        <a href="cotisation.php" style="display:inline-block; padding:12px 25px; background:#28a745; color:white; text-decoration:none; border-radius:5px; font-weight:bold; margin:5px;">
            ➕ Nouvelle cotisation
        </a>
        <a href="pagemembres.php" style="display:inline-block; padding:12px 25px; background:#6c757d; color:white; text-decoration:none; border-radius:5px; font-weight:bold; margin:5px;">
            👥 Liste des membres
        </a>
    </div>

    <!-- ===== SCRIPT JAVASCRIPT POUR LES ONGLETS ===== -->
    <script>
        /**
         * Fonction pour afficher un onglet spécifique
         * 
         * @param {string} tabName - ID de l'onglet à afficher ('payes' ou 'impayes')
         */
        function showTab(tabName) {
            // ===== 1. MASQUER TOUS LES CONTENUS =====

            /**
             * querySelectorAll() : Sélectionne tous les éléments avec la classe 'tab-content'
             * forEach() : Pour chaque élément
             * classList.remove('active') : Retire la classe 'active' (masque le contenu)
             */
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(content => content.classList.remove('active'));

            // ===== 2. DÉSACTIVER TOUS LES ONGLETS =====

            /**
             * Retire la classe 'active' de tous les boutons d'onglets
             */
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));

            // ===== 3. ACTIVER L'ONGLET SÉLECTIONNÉ =====

            /**
             * getElementById() : Récupère l'élément par son ID
             * classList.add('active') : Ajoute la classe 'active' (affiche le contenu)
             */
            document.getElementById(tabName).classList.add('active');

            /**
             * event.target : L'élément qui a déclenché l'événement (le bouton cliqué)
             * Ajoute la classe 'active' au bouton cliqué
             */
            event.target.classList.add('active');
        }
    </script>

</body>

</html>