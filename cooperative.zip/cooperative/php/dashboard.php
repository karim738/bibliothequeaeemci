<!DOCTYPE html>
<html lang="fr">

<head>
    <!-- Définition de l'encodage des caractères -->
    <meta charset="UTF-8">
    
    <!-- Configuration responsive pour mobile -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Lien vers la feuille de style CSS -->
    <link rel="stylesheet" href="../css/style.css">
    
    <!-- Titre de la page -->
    <title>Tableau de bord - Cotisations</title>
    
    <!-- ===== STYLES CSS INTÉGRÉS ===== -->
    <style>
        /* Conteneur principal du tableau de bord */
        .dashboard-container {
            max-width: 1200px;      /* Largeur maximale */
            margin: 0 auto;         /* Centrage horizontal */
            padding: 20px;          /* Espacement intérieur */
        }

        /* Section d'en-tête avec dégradé */
        .header-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .header-section h1 {
            margin: 0;
        }

        /* Grille de statistiques (responsive) */
        .stats-grid {
            display: grid;
            /* Colonnes auto-adaptatives : min 250px, max 1fr (fraction restante) */
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;              /* Espacement entre les cartes */
            margin-bottom: 30px;
        }

        /* Carte de statistique individuelle */
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);  /* Ombre légère */
            border-left: 4px solid #007bff;            /* Bordure gauche colorée */
        }

        .stat-card h3 {
            margin: 0 0 10px 0;
            color: #666;
            font-size: 14px;
            text-transform: uppercase;  /* Texte en majuscules */
        }

        .stat-card .value {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-card .subtitle {
            color: #999;
            font-size: 12px;
        }

        /* Section de filière */
        .filiere-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .filiere-section h2 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #007bff;
            padding-bottom: 10px;
        }

        /* Tableau des filières */
        .filiere-table {
            width: 100%;
            border-collapse: collapse;  /* Fusionne les bordures */
            margin-top: 20px;
        }

        .filiere-table th {
            background: #f8f9fa;
            padding: 15px;
            text-align: left;
            font-weight: bold;
            color: #333;
            border-bottom: 2px solid #dee2e6;
        }

        .filiere-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
        }

        .filiere-table tr:hover {
            background: #f8f9fa;  /* Effet survol */
        }

        /* Barre de progression */
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #e9ecef;
            border-radius: 10px;
            overflow: hidden;       /* Cache le contenu qui dépasse */
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #28a745 0%, #20c997 100%);
            transition: width 0.3s;  /* Animation fluide */
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 11px;
            font-weight: bold;
        }

        /* Conteneur des boutons d'action */
        .action-buttons {
            margin: 20px 0;
            display: flex;
            gap: 10px;              /* Espacement entre boutons */
        }

        /* Style des boutons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-weight: bold;
        }

        .btn-primary {
            background: #007bff;
            color: white;
        }

        .btn-success {
            background: #28a745;
            color: white;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn:hover {
            opacity: 0.9;  /* Légère transparence au survol */
        }
    </style>
</head>

<body>
    <div class="dashboard-container">
        
        <!-- ===== EN-TÊTE DU TABLEAU DE BORD ===== -->
        <div class="header-section">
            <h1>📊 Tableau de bord des cotisations</h1>
            <p>Vue d'ensemble et statistiques détaillées</p>
        </div>

        <?php
        /**
         * ========================================
         * SECTION PHP : RÉCUPÉRATION DES STATISTIQUES
         * ========================================
         */
        
        // Inclusion du fichier de connexion à la BD
        include("connexionbd.php");

        // ===== STATISTIQUES GLOBALES =====
        
        /**
         * Requête pour obtenir les statistiques générales :
         * - Nombre total de membres
         * - Nombre total de cotisations
         * - Montant total collecté
         * - Nombre de membres à jour (ayant versé ≥ 25000 FCFA)
         * 
         * ⚠️ ERREUR CORRIGÉE : Utilisation de la table 'membre' au lieu de 'inscription'
         * ⚠️ ERREUR CORRIGÉE : Jointure sur 'id_membre' au lieu de 'nom'
         */
        $stats_global = $bdd->query("SELECT 
            COUNT(DISTINCT m.id) as total_membre,
            COUNT(c.id_cotisation) as total_cotisation,
            COALESCE(SUM(c.montant), 0) as montant_total,
            COUNT(DISTINCT CASE WHEN total_verse.total >= 25000 THEN total_verse.id_membre END) as membre_a_jour
            FROM membre m
            LEFT JOIN cotisation c ON m.id = c.id_membre
            LEFT JOIN (
                SELECT id_membre, SUM(montant) as total 
                FROM cotisation
                GROUP BY id_membre
            ) total_verse ON m.id = total_verse.id_membre
        ")->fetch();

        /**
         * Calcul du taux de paiement (pourcentage de membres à jour)
         * 
         * Opérateur ternaire : condition ? valeur_si_vrai : valeur_si_faux
         * Si total_membre > 0, on calcule le pourcentage
         * Sinon, on retourne 0 pour éviter une division par zéro
         */
        $taux_paiement = $stats_global['total_membre'] > 0
            ? ($stats_global['membre_a_jour'] / $stats_global['total_membre']) * 100
            : 0;

        // ===== STATISTIQUES PAR FILIÈRE =====
        
        /**
         * Requête pour obtenir les statistiques détaillées par filière :
         * - Nom de la filière (Café, Cacao, etc.)
         * - Nombre de membres dans chaque filière
         * - Montant total collecté par filière
         * - Nombre de membres à jour dans cette filière
         * - Nombre de membres en retard dans cette filière
         * 
         * ⚠️ ERREUR CORRIGÉE : Utilisation de m.id au lieu de m.nomcomplet
         * ⚠️ ERREUR CORRIGÉE : Jointure sur id_membre
         */
        $stats_filieres = $bdd->query("SELECT 
            m.domaine as filiere,
            COUNT(DISTINCT m.id) as nombre_membre,
            COALESCE(SUM(c.montant), 0) as montant_collecte,
            COUNT(DISTINCT CASE WHEN total_verse.total >= 25000 THEN total_verse.id_membre END) as membres_a_jour,
            COUNT(DISTINCT CASE WHEN COALESCE(total_verse.total, 0) < 25000 THEN m.id END) as membre_retard
            FROM membre m
            LEFT JOIN cotisation c ON m.id = c.id_membre
            LEFT JOIN (
                SELECT id_membre, SUM(montant) as total 
                FROM cotisation
                GROUP BY id_membre
            ) total_verse ON m.id = total_verse.id_membre
            GROUP BY m.domaine
            ORDER BY montant_collecte DESC
        ")->fetchAll();
        ?>

        <!-- ===== CARTES DE STATISTIQUES GLOBALES ===== -->
        <div class="stats-grid">
            
            <!-- Carte 1 : Total des membres -->
            <div class="stat-card">
                <h3>Total Membres</h3>
                <!-- 
                    ⚠️ ERREUR CORRIGÉE : 'total_membre' au lieu de 'total_membres'
                    number_format() : Formate le nombre avec séparateurs de milliers
                -->
                <div class="value"><?= number_format($stats_global['total_membre']) ?></div>
                <div class="subtitle">Inscrits à la coopérative</div>
            </div>
            
            <!-- Carte 2 : Montant total collecté -->
            <div class="stat-card" style="border-left-color: #28a745;">
                <h3>Montant Total Collecté</h3>
                <div class="value" style="color: #28a745;"><?= number_format($stats_global['montant_total']) ?> FCFA</div>
                <div class="subtitle">Toutes filières confondues</div>
            </div>
            
            <!-- Carte 3 : Membres à jour -->
            <div class="stat-card" style="border-left-color: #17a2b8;">
                <h3>Membres à Jour</h3>
                <!-- ⚠️ ERREUR CORRIGÉE : 'membre_a_jour' au lieu de 'membres_a_jour' -->
                <div class="value" style="color: #17a2b8;"><?= number_format($stats_global['membre_a_jour']) ?></div>
                <div class="subtitle">≥ 25 000 FCFA</div>
            </div>
            
            <!-- Carte 4 : Taux de paiement -->
            <div class="stat-card" style="border-left-color: #ffc107;">
                <h3>Taux de Paiement</h3>
                <!-- 
                    number_format($taux_paiement, 1) : Formate avec 1 décimale
                    Exemple : 75.5%
                -->
                <div class="value" style="color: #ffc107;"><?= number_format($taux_paiement, 1) ?>%</div>
                <div class="subtitle">Cotisations complètes</div>
            </div>
        </div>

        <!-- ===== BOUTONS D'ACTION ===== -->
        <div class="action-buttons">
            <!-- Lien vers la liste complète des cotisations -->
            <a href="listecotisation.php" class="btn btn-primary">📋 Liste complète</a>
            
            <!-- Lien vers le statut des membres -->
            <a href="statut_paiements.php" class="btn btn-success">✓ Statut des membres</a>
            
            <!-- Lien vers le formulaire de nouvelle cotisation -->
            <a href="cotisation.php" class="btn btn-info">+ Nouvelle cotisation</a>
        </div>

        <!-- ===== TABLEAU DES STATISTIQUES PAR FILIÈRE ===== -->
        <div class="filiere-section">
            <h2>Statistiques par Filière</h2>

            <table class="filiere-table">
                <thead>
                    <tr>
                        <th>Filière</th>
                        <th>Membres</th>
                        <th>À jour</th>
                        <th>En retard</th>
                        <th>Montant collecté</th>
                        <th>Taux de paiement</th>
                        <th>Progression</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    /**
                     * Vérification : Y a-t-il des filières ?
                     * count() retourne le nombre d'éléments dans le tableau
                     */
                    if (count($stats_filieres) > 0): 
                    ?>
                        <?php 
                        /**
                         * Boucle à travers chaque filière
                         * foreach : Pour chaque élément de $stats_filieres
                         */
                        foreach ($stats_filieres as $filiere): 
                        ?>
                            <?php
                            /**
                             * Calcul du taux de paiement pour cette filière
                             * 
                             * ⚠️ ERREUR CORRIGÉE : 'nombre_membre' au lieu de 'nombre_membres'
                             */
                            $taux_filiere = $filiere['nombre_membre'] > 0
                                ? ($filiere['membres_a_jour'] / $filiere['nombre_membre']) * 100
                                : 0;
                            ?>
                            <tr>
                                <!-- Nom de la filière -->
                                <td><strong><?= htmlspecialchars($filiere['filiere']) ?></strong></td>
                                
                                <!-- Nombre total de membres -->
                                <td><?= number_format($filiere['nombre_membre']) ?></td>
                                
                                <!-- Nombre de membres à jour (en vert) -->
                                <td style="color: green;"><strong><?= number_format($filiere['membres_a_jour']) ?></strong></td>
                                
                                <!-- Nombre de membres en retard (en rouge) -->
                                <td style="color: red;"><strong><?= number_format($filiere['membre_retard']) ?></strong></td>
                                
                                <!-- Montant collecté pour cette filière -->
                                <td><strong><?= number_format($filiere['montant_collecte']) ?> FCFA</strong></td>
                                
                                <!-- Taux de paiement en pourcentage -->
                                <td><?= number_format($taux_filiere, 1) ?>%</td>
                                
                                <!-- Barre de progression visuelle -->
                                <td>
                                    <div class="progress-bar">
                                        <!-- 
                                            La largeur de la barre = taux de paiement
                                            style="width: X%" : Définit la largeur dynamiquement
                                        -->
                                        <div class="progress-fill" style="width: <?= $taux_filiere ?>%">
                                            <?= number_format($taux_filiere, 0) ?>%
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                        <!-- ===== LIGNE DE TOTAL ===== -->
                        <tr style="background: #f0f0f0; font-weight: bold;">
                            <td>TOTAL</td>
                            <td><?= number_format($stats_global['total_membre']) ?></td>
                            <td style="color: green;"><?= number_format($stats_global['membre_a_jour']) ?></td>
                            <td style="color: red;">
                                <!-- Calcul : Total - À jour = En retard -->
                                <?= number_format($stats_global['total_membre'] - $stats_global['membre_a_jour']) ?>
                            </td>
                            <td><?= number_format($stats_global['montant_total']) ?> FCFA</td>
                            <td><?= number_format($taux_paiement, 1) ?>%</td>
                            <td>-</td>
                        </tr>
                    <?php else: ?>
                        <!-- Si aucune donnée n'est disponible -->
                        <tr>
                            <td colspan="7" style="text-align: center;">Aucune donnée disponible</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ===== ACCÈS RAPIDE PAR FILIÈRE ===== -->
        <div class="filiere-section">
            <h2>Accès rapide par filière</h2>
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-top: 15px;">
                <?php 
                /**
                 * Création d'un bouton pour chaque filière
                 * Ces boutons redirigent vers la liste des cotisations filtrée
                 */
                foreach ($stats_filieres as $filiere): 
                ?>
                    <!-- 
                        urlencode() : Encode la chaîne pour l'URL
                        Exemple : "Café et Cacao" devient "Caf%C3%A9+et+Cacao"
                    -->
                    <a href="listecotisation.php?filiere=<?= urlencode($filiere['filiere']) ?>"
                        class="btn btn-primary"
                        style="font-size: 14px;">
                        <?= htmlspecialchars($filiere['filiere']) ?>
                        (<?= $filiere['nombre_membre'] ?>)
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</body>

</html>
