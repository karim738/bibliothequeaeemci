<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Vérifier si l'email existe
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(50)); // Générer un token sécurisé
        $stmt = $conn->prepare("UPDATE admin SET reset_token = ?, reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = ?");
        $stmt->bind_param("ss", $token, $email);
        $stmt->execute();

        $resetLink = "http://ton-site.com/reset_password.php?token=$token";

        // Simuler l'envoi de l'email (Affichage à l'écran pour tester)
        echo "Lien de réinitialisation : <a href='$resetLink'>$resetLink</a>";

        // Utiliser mail() pour envoyer l'email (ou un service SMTP comme PHPMailer)
        // mail($email, "Réinitialisation de votre mot de passe", "Cliquez sur ce lien : $resetLink");
    } else {
        echo "Adresse email non reconnue.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">🔑 Mot de passe oublié</h2>
    <form method="POST" class="mx-auto" style="max-width: 400px;">
        <label class="form-label">Entrez votre adresse email :</label>
        <input type="email" name="email" class="form-control" required>
        <button type="submit" class="btn btn-primary mt-3 w-100">Envoyer le lien</button>
    </form>
</div>

</body>
</html>
