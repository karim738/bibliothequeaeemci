<?php
$host = "localhost";
$user = "root";  // Remplace par ton utilisateur MySQL
$pass = "";      // Remplace par ton mot de passe MySQL
$dbname = "gestion_pdf";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}
?>
