<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Récupérer le fichier à supprimer
    $stmt = $conn->prepare("SELECT chemin FROM fichiers WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $file = $result->fetch_assoc();

    if ($file) {
        $filePath = $file['chemin'];

        // Supprimer le fichier du serveur
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Supprimer l'entrée de la base de données
        $stmt = $conn->prepare("DELETE FROM fichiers WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

header("Location: admin.php");
exit;
?>
