<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    // Vérifier si le token est valide
    $stmt = $conn->prepare("SELECT * FROM admin WHERE reset_token = ? AND reset_expires > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE admin SET password = ?, reset_token = NULL, reset_expires = NULL WHERE reset_token = ?");
        $stmt->bind_param("ss", $new_password, $token);
        $stmt->execute();
        echo "Votre mot de passe a été réinitialisé. <a href='login.php'>Connexion</a>";
    } else {
        echo "Lien invalide ou expiré.";
    }
} else {
    $token = $_GET['token'] ?? '';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du mot de passe</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">🔑 Réinitialisation du mot de passe</h2>
    <form method="POST" class="mx-auto" style="max-width: 400px;">
        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
        <label class="form-label">Nouveau mot de passe :</label>
        <input type="password" name="new_password" class="form-control" required>
        <button type="submit" class="btn btn-success mt-3 w-100">Réinitialiser</button>
    </form>
</div>

</body>
</html>
