<?php
$host = 'localhost';
$dbname = 'biblukdu_gestion_pdf'; // Remplace avec ton nom de base complet
$username = 'biblukdu_admin'; // Remplace avec ton nom d'utilisateur complet
$password = 'Karim10151@'; // Remplace avec ton mot de passe

// Connexion
$conn = new mysqli($host, $username, $password, $dbname);

// Vérification
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

?>
