<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $categorie = trim($_POST['categorie']);

    // Liste des types de fichiers autorisés (documents, images, PowerPoint)
    $allowedTypes = [
        "application/pdf", // PDF
        "application/msword", // DOC
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // DOCX
        "text/plain", // TXT
        "image/jpeg", // JPG & JPEG
        "image/png", // PNG
        "image/gif", // GIF
        "application/vnd.ms-powerpoint", // PPT
        "application/vnd.openxmlformats-officedocument.presentationml.presentation" // PPTX
    ];

    // Vérification du type MIME
    if (!in_array($file['type'], $allowedTypes)) {
        die("❌ Erreur : Seuls les fichiers PDF, DOCX, DOC, TXT, PPT, PPTX, JPG, PNG et GIF sont autorisés.");
    }

    // Vérification de la taille (max 15 Mo)
    if ($file['size'] > 15 * 1024 * 1024) {
        die("❌ Erreur : Le fichier est trop volumineux (15 Mo max).");
    }

    // Création du dossier uploads/ s'il n'existe pas
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Génération d'un nom de fichier unique pour éviter les conflits
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $uniqueName = uniqid('file_', true) . '.' . $extension;
    $filePath = $uploadDir . $uniqueName;

    // Déplacement du fichier uploadé vers le dossier final
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        // Sécurisation du nom du fichier avant insertion en base de données
        $safeFileName = htmlspecialchars($file['name'], ENT_QUOTES, 'UTF-8');

        // Insertion dans la base de données
        $stmt = $conn->prepare("INSERT INTO fichiers (nom_fichier, chemin, categorie) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $safeFileName, $filePath, $categorie);
        $stmt->execute();
        $stmt->close();

        // Redirection avec un message de succès
        header("Location: admin.php?success=1");
    } else {
        die("❌ Erreur lors du téléversement du fichier.");
    }
}
?>
