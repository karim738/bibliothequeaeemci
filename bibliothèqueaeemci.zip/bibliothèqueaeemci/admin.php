<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

include 'config.php';

// Récupérer tous les fichiers
$sql = "SELECT * FROM fichiers ORDER BY date_upload DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gestion des Documents</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2 class="text-center">🔐 Administrateur</h2>

    <!-- Bouton pour revenir à l'accueil -->
    <a href="fichier.php" class="btn btn-secondary mb-3">🏠 Retour à la bibliothèque</a>

    <!-- Formulaire d'ajout de fichier -->
    <div class="mb-4 p-3 bg-light border rounded">
        <h4>📤 Ajouter un Document</h4>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-4">
                    <input type="file" name="file" class="form-control" accept=".pdf,.docx,.doc,.txt" required>
                </div>
                <div class="col-md-4">
                    <input type="text" name="categorie" class="form-control" placeholder="Catégorie (ex: Cours, Docs)" required>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">✅ Ajouter</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Tableau des fichiers -->
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Nom du Fichier</th>
                <th>Catégorie</th>
                <th>Date d'Upload</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['nom_fichier']) ?></td>
                    <td><?= htmlspecialchars($row['categorie']) ?></td>
                    <td><?= $row['date_upload'] ?></td>
                    <td>
                        <a href="<?= htmlspecialchars($row['chemin']) ?>" class="btn btn-success btn-sm" target="_blank">📂 Ouvrir</a>
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">✏ Modifier</a>
                        <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Voulez-vous vraiment supprimer ce fichier ?');">🗑 Supprimer</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
